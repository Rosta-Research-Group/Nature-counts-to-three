#!/usr/bin/env python3
from __future__ import annotations

import subprocess
from pathlib import Path

# =========================
# EDIT THESE PATHS
# =========================
IN_FASTA = Path(r"./all_sequences__clustered_only.fasta")
OUTDIR  = Path(r"./")
OUTDIR.mkdir(parents=True, exist_ok=True)

# Tools (leave as names if on PATH; otherwise put full exe path)
CDHIT   = "cd-hit"     # or r"C:\path\to\cd-hit.exe"
MAFFT   = "mafft"      # or r"C:\path\to\mafft.bat"
FASTTREE = "FastTree"  # or "FastTreeMP" or full path

# Parameters
CDHIT_IDENTITY = 0.70   # 0.5–0.7 is typical for large sets
CDHIT_WORD     = 5      # auto-ish for 0.7; for 0.5 use 3
MAFFT_THREADS  = 4      # adjust
USE_FASTTREE_MODEL = ["-lg", "-gamma"]  # reasonable default for proteins

def run(cmd: list[str], cwd: Path | None = None) -> None:
    print("[CMD]", " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=str(cwd) if cwd else None, check=True)

def main():
    if not IN_FASTA.exists():
        raise FileNotFoundError(f"Missing input FASTA: {IN_FASTA}")

    rep_fasta = OUTDIR / f"rep_cdhit_{int(CDHIT_IDENTITY*100)}.fasta"
    rep_clstr = OUTDIR / f"rep_cdhit_{int(CDHIT_IDENTITY*100)}.fasta.clstr"
    aln_fasta = OUTDIR / f"rep_cdhit_{int(CDHIT_IDENTITY*100)}__mafft.fasta"
    tree_nwk  = OUTDIR / f"rep_cdhit_{int(CDHIT_IDENTITY*100)}__fasttree.nwk"

    # 1) CD-HIT (representatives)
    run([
        CDHIT,
        "-i", str(IN_FASTA),
        "-o", str(rep_fasta),
        "-c", str(CDHIT_IDENTITY),
        "-n", str(CDHIT_WORD),
        "-M", "0",       # use all available memory
        "-d", "0",       # keep full headers
    ])
    print(f"[INFO] CD-HIT representatives written: {rep_fasta}", flush=True)
    if rep_clstr.exists():
        print(f"[INFO] CD-HIT clusters file: {rep_clstr}", flush=True)

    # 2) MAFFT alignment
    # MAFFT writes to stdout, so redirect to file.
    print("[CMD] mafft --auto ... > aln", flush=True)
    with aln_fasta.open("w", encoding="utf-8") as out:
        subprocess.run(
            [MAFFT, "--auto", "--thread", str(MAFFT_THREADS), str(rep_fasta)],
            check=True,
            stdout=out
        )
    print(f"[INFO] Alignment written: {aln_fasta}", flush=True)

    # 3) FastTree
    # FastTree reads the alignment and outputs Newick to stdout.
    print("[CMD] FastTree ... > tree", flush=True)
    with tree_nwk.open("w", encoding="utf-8") as out:
        subprocess.run(
            [FASTTREE, *USE_FASTTREE_MODEL, str(aln_fasta)],
            check=True,
            stdout=out
        )
    print(f"[INFO] Newick tree written: {tree_nwk}", flush=True)

    print("\n[INFO] Next step: color tips by structural cluster (iTOL or python).", flush=True)

if __name__ == "__main__":
    main()
