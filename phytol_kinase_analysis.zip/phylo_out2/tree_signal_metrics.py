#!/usr/bin/env python3
"""
Purpose:
  Quantify whether structural clusters show phylogenetic signal on an existing Newick tree.

What this script does:
  1) Reads a Newick tree
  2) Reads accession_to_cluster.tsv
  3) Parses UniProt accessions from leaf labels using a robust, mapping-aware parser
  4) Assigns clusters to tips; writes an audit of label parsing (including failures)
  5) Computes within- vs between-cluster patristic distances (with sampling for scale)
  6) Computes nearest-neighbor concordance among labeled tips
  7) Writes summaries + plots

Outputs (in OUTDIR):
  - tip_label_parsing_audit.tsv
  - tree_signal_summary.tsv
  - labeled_tip_cluster_counts.tsv
  - nearest_neighbor_detail.tsv
  - patristic_within_vs_between.png
  - nearest_neighbor_concordance.png
"""

from __future__ import annotations

import random
import re
from collections import Counter
from itertools import combinations
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Any

import matplotlib.pyplot as plt
import pandas as pd
from Bio import Phylo


# ----------------------------
# CONFIG (edit paths)
# ----------------------------
TREE_NWK = Path("rep_cdhit_70__fasttree.nwk")
MAP_TSV = Path("accession_to_cluster.tsv")
OUTDIR = Path("phylo_signal_out")
OUTDIR.mkdir(parents=True, exist_ok=True)

# Performance knobs
MIDPOINT_ROOT = True               # re-root for readability/consistency
MAX_PAIR_SAMPLES = 250_000         # sample this many pairs if total pairs is larger
RANDOM_SEED = 0

# Audit display
PRINT_MISSING_EXAMPLES = 20


# ----------------------------
# Robust accession parsing (mapping-aware)
# ----------------------------
# Accept 6 or 10 char UniProt accessions (upper-case letters/digits).
# Prefer candidates that exist in the mapping keys.
ACC_TOKEN_RE = re.compile(r"^[A-Z0-9]{6}$|^[A-Z0-9]{10}$")


def _clean_token(tok: str) -> str:
    """
    Strip common suffixes introduced by CD-HIT / toolchains (e.g., /1-300, .1),
    and organism suffix like W9QY77_9ROSA -> W9QY77
    """
    tok = tok.strip()
    tok = re.split(r"[^\w]", tok)[0]          # split at first non [A-Za-z0-9_]
    tok = tok.split("_", 1)[0]                # drop organism suffix
    tok = tok.strip().upper()
    return tok


def extract_uniprot_accession(label: str, valid: Set[str]) -> Optional[str]:
    """
    Extract a UniProt accession from a tree tip label.

    Strategy:
      1) If label has pipe-fields (sp|ACC|NAME or tr|ACC|NAME), try fields first.
      2) Otherwise tokenize label and collect 6/10-char candidates.
      3) Prefer candidates present in `valid` (mapping accessions), else fall back to first plausible.
    """
    if not label:
        return None

    lab = label.strip()

    # 1) Pipe formats: tr|W9QY77|W9QY77_9ROSA
    if "|" in lab:
        parts = [p.strip() for p in lab.split("|") if p.strip()]
        # Prefer anything that matches mapping
        for p in parts:
            cand = _clean_token(p)
            if ACC_TOKEN_RE.match(cand) and cand in valid:
                return cand
        # Otherwise return any plausible accession in pipe-fields
        for p in parts:
            cand = _clean_token(p)
            if ACC_TOKEN_RE.match(cand):
                return cand

    # 2) General tokenization
    raw_tokens = re.split(r"[\s,:;()/]+", lab)
    cands: List[str] = []
    for t in raw_tokens:
        cand = _clean_token(t)
        if ACC_TOKEN_RE.match(cand):
            cands.append(cand)

    # Prefer 10-char then 6-char, but only if in mapping
    for cand in sorted(set(cands), key=lambda x: (-len(x), x)):
        if cand in valid:
            return cand

    # Fall back: first plausible candidate
    if cands:
        return sorted(set(cands), key=lambda x: (-len(x), x))[0]

    return None


# ----------------------------
# Mapping loader (flexible columns)
# ----------------------------
def load_accession_to_cluster(tsv: Path) -> Dict[str, str]:
    """
    Load accession->cluster mapping.
    Accepts common column names:
      - accession, cluster
      - accession, new_cluster
      - or first two columns if unnamed/unexpected
    Returns cluster values as strings for stable downstream handling.
    """
    df = pd.read_csv(tsv, sep="\t")

    cols_lower = {c.lower(): c for c in df.columns}

    acc_col = cols_lower.get("accession", df.columns[0])

    # Try common cluster column names in priority order
    for k in ["cluster", "new_cluster", "struct_cluster", "structural_cluster"]:
        if k in cols_lower:
            cl_col = cols_lower[k]
            break
    else:
        cl_col = df.columns[1] if len(df.columns) > 1 else df.columns[0]

    df[acc_col] = df[acc_col].astype(str).str.strip().str.upper()
    df[cl_col] = df[cl_col].astype(str).str.strip()

    out: Dict[str, str] = {}
    for _, r in df.iterrows():
        acc = str(r[acc_col]).strip().upper()
        cl = str(r[cl_col]).strip()
        if acc and cl and acc.lower() != "nan" and cl.lower() != "nan":
            out[acc] = cl
    return out


# ----------------------------
# Pair sampling
# ----------------------------
def sample_pairs(indices: List[int], max_pairs: int, rng: random.Random) -> List[Tuple[int, int]]:
    """
    Uniformly sample unordered index pairs from indices list.
    If total possible pairs <= max_pairs, return all.
    """
    n = len(indices)
    total = n * (n - 1) // 2
    if total <= max_pairs:
        idx_pairs = list(combinations(range(n), 2))
        return [(indices[i], indices[j]) for i, j in idx_pairs]

    seen = set()
    pairs: List[Tuple[int, int]] = []
    while len(pairs) < max_pairs:
        i = rng.randrange(n)
        j = rng.randrange(n)
        if i == j:
            continue
        a, b = (i, j) if i < j else (j, i)
        if (a, b) in seen:
            continue
        seen.add((a, b))
        pairs.append((indices[a], indices[b]))
    return pairs


# ----------------------------
# Main
# ----------------------------
def main() -> None:
    rng = random.Random(RANDOM_SEED)

    print(f"[INFO] Loading tree: {TREE_NWK}", flush=True)
    tree = Phylo.read(str(TREE_NWK), "newick")

    if MIDPOINT_ROOT:
        try:
            tree.root_at_midpoint()
            print("[INFO] Midpoint-rooted tree.", flush=True)
        except Exception as e:
            print(f"[WARN] Could not midpoint-root tree: {e}", flush=True)

    print(f"[INFO] Loading mapping: {MAP_TSV}", flush=True)
    acc_to_cluster = load_accession_to_cluster(MAP_TSV)
    valid = set(acc_to_cluster.keys())

    tips = list(tree.get_terminals())
    print(f"[INFO] Tips in tree: {len(tips)}", flush=True)

    # Label tips using robust parser; also write a full audit
    labeled: List[Tuple[int, str, str]] = []  # (tip_index, tip_name, cluster)
    audit_rows: List[Tuple[str, Optional[str], Optional[str]]] = []

    for i, tip in enumerate(tips):
        label = tip.name or ""
        acc = extract_uniprot_accession(label, valid)
        cl = acc_to_cluster.get(acc) if acc else None
        if cl is not None:
            labeled.append((i, label, cl))
        audit_rows.append((label, acc, cl))

    audit_df = pd.DataFrame(audit_rows, columns=["tip_label", "parsed_accession", "cluster"])
    audit_path = OUTDIR / "tip_label_parsing_audit.tsv"
    audit_df.to_csv(audit_path, sep="\t", index=False)
    print(f"[INFO] Wrote audit: {audit_path}", flush=True)

    unlabeled = len(tips) - len(labeled)
    print(f"[INFO] Tips with cluster labels: {len(labeled)}", flush=True)
    print(f"[INFO] Tips missing labels: {unlabeled}", flush=True)

    if unlabeled:
        ex = audit_df[audit_df["cluster"].isna()].head(PRINT_MISSING_EXAMPLES)
        if len(ex) > 0:
            print(f"[INFO] Example missing tip labels (showing up to {PRINT_MISSING_EXAMPLES}):", flush=True)
            for _, r in ex.iterrows():
                print(f"  {r['tip_label']}   (parsed={r['parsed_accession']})", flush=True)

    if len(labeled) < 10:
        raise RuntimeError(
            "Too few labeled tips. Leaf labels still do not match mapping accessions.\n"
            "Inspect phylo_signal_out/tip_label_parsing_audit.tsv and adjust parsing rules if needed."
        )

    # Build quick lookup
    tip_idx_to_cluster = {i: cl for (i, _, cl) in labeled}
    cluster_counts = Counter(tip_idx_to_cluster.values())

    # Compute within/between distances (sampled if large)
    labeled_indices = [i for (i, _, _) in labeled]
    pairs = sample_pairs(labeled_indices, MAX_PAIR_SAMPLES, rng)
    print(
        f"[INFO] Computing patristic distances for {len(labeled_indices)} labeled tips "
        f"(~{len(pairs)} pairs)...",
        flush=True
    )

    within: List[float] = []
    between: List[float] = []

    # Cache tip objects for speed
    tip_objs = tips

    for k, (i, j) in enumerate(pairs, start=1):
        ci = tip_idx_to_cluster[i]
        cj = tip_idx_to_cluster[j]
        d = tree.distance(tip_objs[i], tip_objs[j])
        if ci == cj:
            within.append(d)
        else:
            between.append(d)
        if k % 50_000 == 0:
            print(f"  [INFO] distances: {k}/{len(pairs)}", flush=True)

    # Nearest-neighbor concordance (for labeled tips only)
    nn_rows: List[Dict[str, Any]] = []
    labeled_tip_objs = [(i, tip_objs[i]) for i in labeled_indices]

    for n, (i, ti) in enumerate(labeled_tip_objs, start=1):
        best_d: Optional[float] = None
        best_j: Optional[int] = None
        for j, tj in labeled_tip_objs:
            if i == j:
                continue
            d = tree.distance(ti, tj)
            if best_d is None or d < best_d:
                best_d = d
                best_j = j

        nn_rows.append({
            "tip_i": tip_objs[i].name,
            "cluster_i": tip_idx_to_cluster[i],
            "nearest_tip": tip_objs[best_j].name if best_j is not None else None,
            "cluster_nearest": tip_idx_to_cluster[best_j] if best_j is not None else None,
            "distance": best_d,
            "same_cluster": (tip_idx_to_cluster[i] == tip_idx_to_cluster[best_j]) if best_j is not None else None
        })

        if n % 200 == 0:
            print(f"  [INFO] nearest-neighbor: {n}/{len(labeled_tip_objs)}", flush=True)

    nn_df = pd.DataFrame(nn_rows)

    # Write summary TSV
    summary = {
        "tips_in_tree": len(tips),
        "tips_labeled": len(labeled),
        "tips_unlabeled": unlabeled,
        "clusters_in_tree_labeled": len(cluster_counts),
        "within_n": len(within),
        "between_n": len(between),
        "within_mean": float(pd.Series(within).mean()) if within else None,
        "within_median": float(pd.Series(within).median()) if within else None,
        "between_mean": float(pd.Series(between).mean()) if between else None,
        "between_median": float(pd.Series(between).median()) if between else None,
        "nearest_neighbor_concordance": float(nn_df["same_cluster"].mean()) if not nn_df.empty else None,
        "max_pair_samples": MAX_PAIR_SAMPLES,
        "midpoint_rooted": MIDPOINT_ROOT,
        "random_seed": RANDOM_SEED,
    }

    summary_path = OUTDIR / "tree_signal_summary.tsv"
    pd.DataFrame([summary]).to_csv(summary_path, sep="\t", index=False)

    # Cluster counts
    counts_path = OUTDIR / "labeled_tip_cluster_counts.tsv"
    pd.DataFrame(
        [{"cluster": k, "count": v} for k, v in sorted(cluster_counts.items(), key=lambda x: (str(x[0]), x[1]))]
    ).to_csv(counts_path, sep="\t", index=False)

    # Nearest neighbor detail
    nn_path = OUTDIR / "nearest_neighbor_detail.tsv"
    nn_df.to_csv(nn_path, sep="\t", index=False)

    # Plot within vs between
    plt.figure(figsize=(7, 5))
    plt.hist(within, bins=50, alpha=0.6, label=f"within (n={len(within)})")
    plt.hist(between, bins=50, alpha=0.6, label=f"between (n={len(between)})")
    plt.xlabel("patristic distance")
    plt.ylabel("count")
    plt.title("Patristic distance: within vs between structural clusters")
    plt.legend()
    out1 = OUTDIR / "patristic_within_vs_between.png"
    plt.tight_layout()
    plt.savefig(out1, dpi=200)
    plt.close()

    # Nearest-neighbor concordance plot
    concord = nn_df["same_cluster"].value_counts(dropna=True).to_dict()
    same = int(concord.get(True, 0))
    diff = int(concord.get(False, 0))

    plt.figure(figsize=(5, 4))
    plt.bar(["same cluster", "different cluster"], [same, diff])
    plt.ylabel("tips")
    plt.title("Nearest labeled neighbor concordance")
    out2 = OUTDIR / "nearest_neighbor_concordance.png"
    plt.tight_layout()
    plt.savefig(out2, dpi=200)
    plt.close()

    print(f"[INFO] Wrote: {summary_path}", flush=True)
    print(f"[INFO] Wrote: {counts_path}", flush=True)
    print(f"[INFO] Wrote: {nn_path}", flush=True)
    print(f"[INFO] Saved: {out1}", flush=True)
    print(f"[INFO] Saved: {out2}", flush=True)
    print("[INFO] Done.", flush=True)


if __name__ == "__main__":
    main()

