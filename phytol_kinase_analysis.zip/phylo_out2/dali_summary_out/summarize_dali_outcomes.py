#!/usr/bin/env python3
"""
Purpose: Convert a folder of DALI *_zscores.tsv outputs into per-query/per-accession summaries.
Outputs best Z (overall and optional per-reference), best RMSD, best reference, and a no-hit flag.
Designed to tolerate empty files and trailing non-tabular lines in DALI outputs.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional, Tuple, List

import pandas as pd


# ----------------------------
# CONFIG (edit paths)
# ----------------------------
DALI_DIR = Path(r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\phytol kinase\zhijing_code\dali_output2")  # folder with qxxxA_zscores.tsv
DALI_ID_MAP = Path(r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\phytol kinase\zhijing_code\dali_output2\dali_id_map.tsv")  # query_id<TAB>Accession.pdb (optional)
OUTDIR = Path(r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\phytol kinase\zhijing_code\dali_output2\dali_summary_out")
OUTDIR.mkdir(parents=True, exist_ok=True)

# Optional: focus on specific references by prefix (case-insensitive), e.g. AFST, 4Q2G, 5GUF
TRACK_REFS = ["AFST", "4Q2G", "5GUF", "AFB4"]


# ----------------------------
# Helpers
# ----------------------------
def load_id_map(path: Path) -> Dict[str, str]:
    """
    dali_id_map.tsv format example:
      qaab    A0A022RIW5.pdb
    Returns query -> accession (without .pdb)
    """
    m: Dict[str, str] = {}
    if not path.exists():
        return m
    df = pd.read_csv(path, sep="\t", header=None, names=["query", "pdb"])
    for _, r in df.iterrows():
        q = str(r["query"]).strip()
        pdb = str(r["pdb"]).strip()
        acc = Path(pdb).stem
        m[q] = acc
    return m

def read_dali_tsv(path: Path) -> Optional[pd.DataFrame]:
    """
    Read only the well-formed tabular part of the DALI TSV.
    Stops at first line that does not have expected number of columns.
    """
    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    if not lines:
        return None

    # find header
    header_idx = None
    for i, ln in enumerate(lines):
        if ln.strip().lower().startswith("query") and "\t" in ln:
            header_idx = i
            break
    if header_idx is None:
        return None

    header = lines[header_idx].split("\t")
    ncol = len(header)

    data_lines = []
    for ln in lines[header_idx+1:]:
        if not ln.strip():
            continue
        parts = ln.split("\t")
        if len(parts) != ncol:
            # trailing non-table region reached
            break
        data_lines.append(ln)

    if not data_lines:
        return None

    from io import StringIO
    txt = "\n".join([lines[header_idx]] + data_lines)
    df = pd.read_csv(StringIO(txt), sep="\t")

    # enforce numeric for Z/rmsd if present
    for col in ["Z", "rmsd"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=["Z"]) if "Z" in df.columns else df
    return df if not df.empty else None


# ----------------------------
# Main
# ----------------------------
def main():
    idmap = load_id_map(DALI_ID_MAP)

    files = sorted(DALI_DIR.glob("*_zscores.tsv"))
    if not files:
        raise RuntimeError(f"No *_zscores.tsv found in: {DALI_DIR}")

    rows = []
    empty = 0
    for f in files:
        q = f.stem.replace("_zscores", "")
        df = read_dali_tsv(f)
        if df is None:
            empty += 1
            rows.append({
                "query": q,
                "accession": idmap.get(q, None),
                "no_hit": 1,
                "best_Z": None,
                "best_rmsd": None,
                "best_ref": None,
            })
            continue

        # best overall
        best_row = df.loc[df["Z"].idxmax()]
        out = {
            "query": q,
            "accession": idmap.get(q, None),
            "no_hit": 0,
            "best_Z": float(best_row["Z"]),
            "best_rmsd": float(best_row["rmsd"]) if "rmsd" in df.columns and pd.notna(best_row["rmsd"]) else None,
            "best_ref": str(best_row["reference"]),
        }

        # optionally track specific refs
        for r in TRACK_REFS:
            mask = df["reference"].astype(str).str.upper().str.startswith(r.upper())
            if mask.any():
                out[f"bestZ_to_{r}"] = float(df.loc[mask, "Z"].max())
            else:
                out[f"bestZ_to_{r}"] = None

        rows.append(out)

    out_df = pd.DataFrame(rows)
    out_path = OUTDIR / "dali_outcomes_by_query.tsv"
    out_df.to_csv(out_path, sep="\t", index=False)
    print(f"[INFO] Wrote: {out_path}")
    print(f"[INFO] Total queries: {len(out_df)} | no-hit: {int(out_df['no_hit'].sum())} | parsed hits: {len(out_df) - int(out_df['no_hit'].sum())}")
    print(f"[INFO] Empty/no-hit TSV files: {empty}")


if __name__ == "__main__":
    main()
