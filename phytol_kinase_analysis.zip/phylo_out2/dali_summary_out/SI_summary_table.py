#!/usr/bin/env python3
"""
Purpose: Build a single, compact Supplementary Information (SI) table that summarizes each structural
cluster by (i) DALI outcomes (Z-score signatures vs key references), (ii) AlphaFold confidence (pLDDT),
and (iii) optional phylogenetic coherence metrics from a FastTree .nwk analysis.

Inputs: cluster assignments (query->cluster), DALI per-query summary TSV, pLDDT-per-model TSV, and
(optionally) nearest-neighbor detail TSV from the tree-signal script. Outputs: TSV + Markdown table.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import re
import numpy as np
import pandas as pd


def _read_tsv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t")


def _coerce_numeric(df: pd.DataFrame, cols: list[str]) -> None:
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")


def _guess_col(df: pd.DataFrame, candidates: list[str]) -> str | None:
    for c in candidates:
        if c in df.columns:
            return c
    return None


def _parse_accession_from_query_name(x: str) -> str | None:
    """
    Tries to recover a UniProt-like accession from labels such as:
      A0A010RMP9.pdb, sp|Q9XXXX|..., tr|E1Z5G9|..., etc.
    """
    if not isinstance(x, str) or not x:
        return None

    # A0A...pdb or .cif etc
    m = re.search(r"([A-NR-Z0-9]{6,10})(?:\.\w+)?$", x)
    if m:
        return m.group(1)

    # sp|Q9XXXX|NAME or tr|E1Z5G9|...
    m = re.search(r"\b(?:sp|tr)\|([A-NR-Z0-9]{6,10})\|", x)
    if m:
        return m.group(1)

    return None


def build_cluster_table(
    assign_tsv: Path,
    dali_tsv: Path,
    plddt_tsv: Path,
    nn_detail_tsv: Path | None,
    out_prefix: Path,
    z_threshold: float = 10.0,
) -> None:
    df_assign = _read_tsv(assign_tsv)

    # Required: query + cluster column
    qcol = _guess_col(df_assign, ["query", "query_id", "query_name"])
    ccol = _guess_col(df_assign, ["cluster", "new_cluster", "kmeans_cluster"])
    if qcol is None or ccol is None:
        raise SystemExit(f"[ERROR] Cannot find query/cluster columns in: {assign_tsv}")

    df_assign = df_assign[[qcol, ccol]].rename(columns={qcol: "query", ccol: "cluster"})
    df_assign["cluster"] = pd.to_numeric(df_assign["cluster"], errors="coerce")

    df_dali = _read_tsv(dali_tsv)
    dq = _guess_col(df_dali, ["query", "query_id"])
    if dq is None:
        raise SystemExit(f"[ERROR] Cannot find query column in: {dali_tsv}")
    df_dali = df_dali.rename(columns={dq: "query"})

    # Merge DALI with cluster
    df = df_dali.merge(df_assign, on="query", how="left")

    # Identify key Z columns (these exist in your newer pipeline outputs)
    z_afst = _guess_col(df, ["bestZ_to_AFST", "Z_AFST", "Z_to_AFST"])
    z_afb4 = _guess_col(df, ["bestZ_to_AFB4", "Z_AFB4", "Z_to_AFB4"])
    best_ref = _guess_col(df, ["best_ref", "bestRef", "top1_ref", "top_ref"])
    best_z = _guess_col(df, ["best_Z", "bestZ", "best_z"])
    best_rmsd = _guess_col(df, ["best_rmsd", "bestRMSD", "best_rmsd_A"])

    _coerce_numeric(df, [c for c in [z_afst, z_afb4, best_z, best_rmsd] if c])

    # ---------
    # DALI summary per cluster
    # ---------
    agg = {"n_models": ("query", "count")}
    if best_ref:
        agg["top1_mode"] = (best_ref, lambda s: s.dropna().mode().iloc[0] if len(s.dropna().mode()) else np.nan)
    if best_z:
        agg["bestZ_median"] = (best_z, "median")
    if best_rmsd:
        agg["bestRMSD_median"] = (best_rmsd, "median")

    if z_afst:
        agg["Z_AFST_median"] = (z_afst, "median")
        agg[f"frac_Z_AFST_ge{z_threshold:g}"] = (z_afst, lambda s: np.nanmean(s >= z_threshold))
    if z_afb4:
        agg["Z_AFB4_median"] = (z_afb4, "median")
        agg[f"frac_Z_AFB4_ge{z_threshold:g}"] = (z_afb4, lambda s: np.nanmean(s >= z_threshold))

    dali_sum = (
        df.groupby("cluster", dropna=False)
        .agg(**{k: pd.NamedAgg(column=v[0], aggfunc=v[1]) for k, v in agg.items()})
        .reset_index()
        .sort_values("cluster")
    )

    # ---------
    # pLDDT summary per cluster
    # ---------
    df_pl = _read_tsv(plddt_tsv)

    # Accept either (a) pLDDT file already has cluster or (b) merge via accession parsed from query_name
    pl_cluster = _guess_col(df_pl, ["cluster", "new_cluster", "kmeans_cluster"])
    acc_col = _guess_col(df_pl, ["accession", "acc", "uniprot", "id"])
    mlddt_col = _guess_col(df_pl, ["mLDDT", "mean_plddt", "mean_pLDDT"])
    ge70_col = _guess_col(df_pl, ["frac_ge_70", "frac_plddt_ge70", "p70_frac"])
    ge90_col = _guess_col(df_pl, ["frac_ge_90", "frac_plddt_ge90", "p90_frac"])

    if mlddt_col is None:
        raise SystemExit(f"[ERROR] Cannot find mean pLDDT (mLDDT) column in: {plddt_tsv}")

    # If cluster missing, try to merge using accession (from accession column, or parsed from query_name)
    if pl_cluster is None:
        if acc_col is None:
            # Try to parse accession from a name column
            name_col = _guess_col(df_pl, ["query_name", "model", "filename", "pdb_file"])
            if name_col is None:
                raise SystemExit(f"[ERROR] pLDDT TSV lacks both cluster and accession/name columns: {plddt_tsv}")
            df_pl["accession"] = df_pl[name_col].map(_parse_accession_from_query_name)
            acc_col = "accession"
        else:
            df_pl = df_pl.rename(columns={acc_col: "accession"})
            acc_col = "accession"

        # Build accession->cluster map using df_dali query_name if present, otherwise use df_assign query
        # If you have a separate dali_id_map, you can merge it earlier; here we assume query or query_name contains accession.
        df_assign2 = df_assign.copy()
        df_assign2["accession"] = df_assign2["query"].map(_parse_accession_from_query_name)
        acc2cl = df_assign2.dropna(subset=["accession"]).drop_duplicates("accession")[["accession", "cluster"]]
        df_pl = df_pl.merge(acc2cl, on="accession", how="left")
        pl_cluster = "cluster"
    else:
        df_pl = df_pl.rename(columns={pl_cluster: "cluster"})
        pl_cluster = "cluster"

    # Numeric coercion
    _coerce_numeric(df_pl, [pl_cluster, mlddt_col, ge70_col, ge90_col])

    pl_sum = (
        df_pl.groupby("cluster", dropna=False)
        .agg(
            n_plddt=("cluster", "count"),
            mLDDT_median=(mlddt_col, "median"),
            mLDDT_mean=(mlddt_col, "mean"),
            frac_ge70_median=(ge70_col, "median") if ge70_col else (mlddt_col, lambda _: np.nan),
            frac_ge90_median=(ge90_col, "median") if ge90_col else (mlddt_col, lambda _: np.nan),
        )
        .reset_index()
        .sort_values("cluster")
    )

    # ---------
    # Optional: nearest-neighbor concordance per cluster from tree analysis
    # ---------
    nn_sum = None
    if nn_detail_tsv is not None and nn_detail_tsv.exists():
        df_nn = _read_tsv(nn_detail_tsv)
        ci = _guess_col(df_nn, ["cluster_i", "cluster"])
        same = _guess_col(df_nn, ["same_cluster", "same"])
        if ci and same:
            df_nn[ci] = pd.to_numeric(df_nn[ci], errors="coerce")
            df_nn[same] = pd.to_numeric(df_nn[same], errors="coerce")
            nn_sum = (
                df_nn.groupby(ci)
                .agg(tree_tips=("tip_i", "count"), nn_same_frac=(same, "mean"))
                .reset_index()
                .rename(columns={ci: "cluster"})
            )

    # ---------
    # Merge into final table
    # ---------
    out = dali_sum.merge(pl_sum, on="cluster", how="outer")
    if nn_sum is not None:
        out = out.merge(nn_sum, on="cluster", how="left")

    # Make fractions prettier (percent)
    for c in out.columns:
        if c.startswith("frac_") or c.endswith("_frac"):
            out[c] = out[c] * 100.0

    out_tsv = out_prefix.with_suffix(".tsv")
    out_md = out_prefix.with_suffix(".md")

    out.to_csv(out_tsv, sep="\t", index=False)

    # Markdown (rounded for SI readability)
    out_md_df = out.copy()
    for c in out_md_df.columns:
        if out_md_df[c].dtype.kind in "fc":
            out_md_df[c] = out_md_df[c].round(2)
    out_md.write_text(out_md_df.to_markdown(index=False) + "\n", encoding="utf-8")

    print(f"[OK] Wrote: {out_tsv}")
    print(f"[OK] Wrote: {out_md}")


import sys
from pathlib import Path
import argparse

# =============================================================================
# DEFAULTS (your standard locations)
# =============================================================================
DEFAULT_ASSIGN = Path(
    r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\phytol kinase\zhijing_code\cluster_coherence_out2\query_cluster_assignments.tsv"
)
DEFAULT_DALI = Path(
    r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\phytol kinase\zhijing_code\dali_output2\dali_summary_out\dali_outcomes_by_query.tsv"
)
DEFAULT_PLDDT = Path(
    r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\phytol kinase\plddt_out2\plddt_per_model.tsv"
)
DEFAULT_NN_DETAIL = Path(
    r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\phytol kinase\phylo_out2\phylo_signal_out\nearest_neighbor_detail.tsv"
)

# IMPORTANT: this is an output *prefix* (no extension). The script will create .tsv and .md.
DEFAULT_OUT_PREFIX = Path(
    r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\phytol kinase\zhijing_code\dali_output2\dali_summary_out\SI_cluster_summary"
)

DEFAULT_ZTHR = 10.0


def main() -> None:
    """
    If run with no CLI arguments, use the defaults above.
    If run with CLI arguments, allow overriding any defaults.
    """
    if len(sys.argv) == 1:
        # No CLI args: run with defaults
        build_cluster_table(
            assign_tsv=DEFAULT_ASSIGN,
            dali_tsv=DEFAULT_DALI,
            plddt_tsv=DEFAULT_PLDDT,
            nn_detail_tsv=DEFAULT_NN_DETAIL if DEFAULT_NN_DETAIL.exists() else None,
            out_prefix=DEFAULT_OUT_PREFIX,
            z_threshold=DEFAULT_ZTHR,
        )
        return

    # Optional CLI override mode (kept for flexibility)
    ap = argparse.ArgumentParser()
    ap.add_argument("--assign", type=Path, default=DEFAULT_ASSIGN, help="query_cluster_assignments.tsv")
    ap.add_argument("--dali", type=Path, default=DEFAULT_DALI, help="dali_outcomes_by_query.tsv (or analogous)")
    ap.add_argument("--plddt", type=Path, default=DEFAULT_PLDDT, help="plddt_per_model.tsv (or analogous)")
    ap.add_argument("--nn_detail", type=Path, default=DEFAULT_NN_DETAIL, help="nearest_neighbor_detail.tsv (optional)")
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT_PREFIX, help="output prefix (no extension)")
    ap.add_argument("--zthr", type=float, default=DEFAULT_ZTHR, help="Z threshold (default 10)")
    args = ap.parse_args()

    build_cluster_table(
        assign_tsv=args.assign,
        dali_tsv=args.dali,
        plddt_tsv=args.plddt,
        nn_detail_tsv=args.nn_detail if args.nn_detail and args.nn_detail.exists() else None,
        out_prefix=args.out,
        z_threshold=args.zthr,
    )


if __name__ == "__main__":
    main()

