#!/usr/bin/env python3
"""
Purpose:
  Compute mean pLDDT (mLDDT) per AlphaFold PDB model (pLDDT is stored in the B-factor column),
  then optionally join to accession_to_cluster.tsv to summarize confidence by structural cluster.

What it does:
  - Scans a directory of AlphaFold PDBs named like A0A010RMP9.pdb
  - Computes mean/median pLDDT using CA atoms (one value per residue)
  - Writes per-model table + per-cluster summary + simple plots
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import pandas as pd


# ----------------------------
# CONFIG (edit paths)
# ----------------------------
PDB_DIR = Path(r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\phytol kinase\alphafold_models\EC_2_7_1_182")
MAP_TSV = Path(r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\phytol kinase\phylo_out2\accession_to_cluster.tsv")  # optional
OUTDIR = Path(r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\phytol kinase\plddt_out2")
OUTDIR.mkdir(parents=True, exist_ok=True)

USE_CLUSTER_MAP = True


def read_plddt_from_pdb(pdb_path: Path) -> List[float]:
    """
    Extract pLDDT values from B-factor column.
    For AlphaFold PDBs, B-factor is typically pLDDT. Use CA atoms to avoid counting residues multiple times.
    """
    vals: List[float] = []
    with pdb_path.open("r", encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            if not line.startswith("ATOM"):
                continue
            atom = line[12:16].strip()
            if atom != "CA":
                continue
            # B-factor is columns 61-66 in PDB (0-based [60:66])
            bfac = line[60:66].strip()
            try:
                vals.append(float(bfac))
            except ValueError:
                continue
    return vals


def load_map(tsv: Path) -> Dict[str, str]:
    df = pd.read_csv(tsv, sep="\t")
    cols = {c.lower(): c for c in df.columns}
    acc_col = cols.get("accession", df.columns[0])
    cl_col = cols.get("cluster", df.columns[1])
    return {str(a).strip(): str(c).strip() for a, c in zip(df[acc_col], df[cl_col])}


def main() -> None:
    pdbs = sorted(PDB_DIR.glob("*.pdb"))
    if not pdbs:
        raise RuntimeError(f"No PDB files found in {PDB_DIR}")

    acc_to_cluster = load_map(MAP_TSV) if (USE_CLUSTER_MAP and MAP_TSV.exists()) else {}

    rows = []
    for p in pdbs:
        acc = p.stem  # A0A010RMP9
        vals = read_plddt_from_pdb(p)
        if not vals:
            rows.append({"accession": acc, "n_res": 0, "mLDDT": None, "median": None,
                         "frac_ge_70": None, "frac_ge_90": None})
            continue

        ser = pd.Series(vals)
        rows.append({
            "accession": acc,
            "n_res": int(ser.shape[0]),
            "mLDDT": float(ser.mean()),
            "median": float(ser.median()),
            "frac_ge_70": float((ser >= 70).mean()),
            "frac_ge_90": float((ser >= 90).mean()),
            "cluster": acc_to_cluster.get(acc, None) if acc_to_cluster else None
        })

    per_model = pd.DataFrame(rows)
    per_model_path = OUTDIR / "plddt_per_model.tsv"
    per_model.to_csv(per_model_path, sep="\t", index=False)

    print(f"[INFO] Wrote: {per_model_path}")

    # If clusters are available, summarize and plot
    if "cluster" in per_model.columns and per_model["cluster"].notna().any():
        summary = (
            per_model.dropna(subset=["mLDDT"])
            .groupby("cluster")
            .agg(
                n_models=("accession", "count"),
                mLDDT_mean=("mLDDT", "mean"),
                mLDDT_median=("mLDDT", "median"),
                frac70_mean=("frac_ge_70", "mean"),
                frac90_mean=("frac_ge_90", "mean"),
                n_res_median=("n_res", "median"),
            )
            .reset_index()
        )
        summary_path = OUTDIR / "plddt_by_cluster_summary.tsv"
        summary.to_csv(summary_path, sep="\t", index=False)
        print(f"[INFO] Wrote: {summary_path}")

        # Plot mLDDT distribution by cluster (simple overlay histograms)
        plt.figure(figsize=(7, 5))

        plot_df = (
            per_model
            .dropna(subset=["mLDDT"])
            .copy()
        )

        # If cluster values are numeric-like strings, this still works because "-1" compares as string below.
        plot_df = plot_df[plot_df["cluster"].astype(str) != "-1"]

        for cl, sub in plot_df.groupby("cluster"):
            plt.hist(sub["mLDDT"], bins=40, alpha=0.5, label=f"cluster {cl} (n={len(sub)})")

        plt.xlabel("mean pLDDT (mLDDT)")
        plt.ylabel("count")
        plt.title("AlphaFold confidence by structural cluster")
        plt.legend()
        out_png = OUTDIR / "plddt_hist_by_cluster.png"
        plt.tight_layout()
        plt.savefig(out_png, dpi=200)
        plt.close()

    else:
        print("[WARN] No cluster labels joined (MAP_TSV missing or accessions not matching).")


if __name__ == "__main__":
    main()
