#!/usr/bin/env python3

import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans

import seaborn as sns
from typing import Optional, List

# ==========================
# CONFIG
# ==========================
ZSCORE_DIR = Path("dali_output2")
TOP_N = 4
OUTDIR = Path("analysis_output_182")
OUTDIR.mkdir(exist_ok=True)

# Full-matrix defaults
DEFAULT_Z = 0.0
DEFAULT_RMSD = 100.0

# Clustering + reporting controls
N_NEW_CLUSTERS = 3
PRINT_MAIN_ONLY = False          # True => only 1 main rep per cluster
N_REPS_PER_CLUSTER = 3           # typical reps (nearest to centroid)
N_FARTHEST_PER_CLUSTER = 2       # extremes (farthest from centroid)
INCLUDE_PC_EXTREMES = True       # also add min/max PC1 within cluster

ID_MAP_FILE = Path("dali_output2\dali_id_map.tsv")

# ==========================
# PLOT STYLE: LARGE FONTS
# ==========================
FONT_SIZE = 22

plt.rcParams.update({
    "font.size": FONT_SIZE,
    "axes.titlesize": FONT_SIZE,
    "axes.labelsize": FONT_SIZE,
    "xtick.labelsize": FONT_SIZE,
    "ytick.labelsize": FONT_SIZE,
    "legend.fontsize": FONT_SIZE,
    "figure.titlesize": FONT_SIZE,
})


def load_id_map(path: Path) -> dict[str, str]:
    """
    Load dali_id_map.tsv with format: <dali_id>\t<filename>
    Returns dict mapping 4-char dali_id (lowercase) -> original filename.
    """
    if not path.exists():
        print(f"[WARN] ID map not found: {path.resolve()}")
        return {}

    mapping = {}
    for line in path.read_text().splitlines():
        if not line.strip():
            continue
        dali_id, fname = line.split("\t", 1)
        mapping[dali_id.strip().lower()[:4]] = fname.strip()
    print(f"[INFO] Loaded {len(mapping)} IDs from {path}")
    return mapping

id_to_fname = load_id_map(ID_MAP_FILE)

def query_to_filename(query_id: str) -> str:
    """
    Convert query like 'a252A' to original filename using dali_id_map.tsv.
    Falls back to query_id if unknown.
    """
    dali_id = query_id.strip().lower()[:4]  # drop chain
    return id_to_fname.get(dali_id, query_id)

# ==========================
# LOAD DATA
# ==========================
dfs = []
for f in ZSCORE_DIR.glob("*_zscores.tsv"):
    df = pd.read_csv(f, sep="\t")
    if df.empty:
        continue
    df["query"] = f.stem.replace("_zscores", "")
    dfs.append(df)

if not dfs:
    raise RuntimeError("No zscore files found")

all_df = pd.concat(dfs, ignore_index=True)

# normalize reference ID (ignore chain)
all_df["ref_pdb"] = all_df["reference"].astype(str).str[:4].str.upper()

# ensure numeric columns
for col in ["Z", "rmsd"]:
    all_df[col] = pd.to_numeric(all_df[col], errors="coerce")

all_df = all_df.dropna(subset=["Z", "rmsd"])

# ==========================
# COMPUTE RANK PER QUERY
# ==========================
all_df["rank"] = (
    all_df
    .groupby("query")["Z"]
    .rank(ascending=False, method="first")
    .astype(int)
)

# ==========================
# BUILD RANKING SIGNATURES (optional; kept for compatibility)
# ==========================
signatures = {}
for query, qdf in all_df.groupby("query"):
    top_refs = (
        qdf.sort_values("rank")
           .head(TOP_N)["ref_pdb"]
           .tolist()
    )
    if len(top_refs) == TOP_N:
        signatures[query] = tuple(top_refs)

# ============================================================
# FULL-MATRIX FEATURES: ALL REFS × (Z, RMSD) WITH DEFAULTS
# ============================================================
print("\n=== FULL-MATRIX PCA + CLUSTERING (ALL REFERENCES, Z+RMSD) ===")

# Queries and references present in your results
queries = sorted(all_df["query"].unique())
refs = sorted(all_df["ref_pdb"].unique())  # chain-stripped

q_index = {q: i for i, q in enumerate(queries)}
r_index = {r: i for i, r in enumerate(refs)}

n_q = len(queries)
n_r = len(refs)

print(f"[INFO] Queries: {n_q}")
print(f"[INFO] References: {n_r}")
print(f"[INFO] Feature dimension: {2 * n_r} (Z + RMSD per reference)")

# Initialize defaults
Z_mat = np.full((n_q, n_r), DEFAULT_Z, dtype=float)
R_mat = np.full((n_q, n_r), DEFAULT_RMSD, dtype=float)

# Fill observed values
for row in all_df.itertuples(index=False):
    qi = q_index[row.query]
    ri = r_index[row.ref_pdb]
    Z_mat[qi, ri] = row.Z
    R_mat[qi, ri] = row.rmsd

X_full = np.hstack([Z_mat, R_mat])

# Feature names (for PCA loadings)
feature_names = [f"Z_{r}" for r in refs] + [f"RMSD_{r}" for r in refs]

# Scale features (per-feature z-score)
X_scaled = StandardScaler().fit_transform(X_full)

# PCA for 2D visualization
pca = PCA(n_components=2, random_state=0)
X_pca = pca.fit_transform(X_scaled)

full_pca_df = pd.DataFrame({
    "query": queries,
    "PC1": X_pca[:, 0],
    "PC2": X_pca[:, 1],
})

print("[INFO] PCA variance explained:", pca.explained_variance_ratio_)

# --------------------------
# New clusters: fit on FULL space (not on PCs)
# --------------------------
kmeans = KMeans(n_clusters=N_NEW_CLUSTERS, random_state=0, n_init=50)
full_pca_df["new_cluster"] = kmeans.fit_predict(X_scaled)

#plt.figure(figsize=(8, 7))
plt.figure(figsize=(12, 10))

sns.scatterplot(
    data=full_pca_df, x="PC1", y="PC2",
    hue="new_cluster", palette="tab10",
    s=35, alpha=0.9, linewidth=0
)
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title(f"PCA (All Z + RMSD)\nKMeans in full space (k={N_NEW_CLUSTERS})")
plt.tight_layout()
plt.savefig(OUTDIR / "full_matrix_pca_new_clusters.png", dpi=300)
plt.show()

print("\n[INFO] New cluster sizes:")
print(full_pca_df["new_cluster"].value_counts().sort_index())

# --------------------------
# Top PCA loadings (what drives PC1/PC2)
# --------------------------
loadings = pd.DataFrame(
    pca.components_.T,
    index=feature_names,
    columns=["PC1_loading", "PC2_loading"]
)

for pc in ["PC1_loading", "PC2_loading"]:
    top = loadings[pc].abs().sort_values(ascending=False).head(10)
    print(f"\n[INFO] Top 10 features by |{pc}|:")
    for feat, val in top.items():
        print(f"  {feat:14s}  |loading|={val:.4f}")

# --------------------------
# Representative + stats per NEW cluster
# Candidate template = mode of per-query top-1 (max Z) within cluster
# --------------------------

# Derive top-1 template per query (chain-stripped)
top1_ref = (
    all_df.sort_values(["query", "Z"], ascending=[True, False])
         .groupby("query")["ref_pdb"]
         .first()
)

def get_k_nearest_to_centroid(idx: np.ndarray, k: int) -> List[str]:
    """Return k queries closest to centroid in FULL scaled feature space."""
    X_sub = X_scaled[idx]
    center = X_sub.mean(axis=0)
    d = np.linalg.norm(X_sub - center, axis=1)
    order = np.argsort(d)
    rep_idx = idx[order[:min(k, len(order))]]
    return [queries[i] for i in rep_idx]

def get_k_farthest_from_centroid(idx: np.ndarray, k: int) -> List[str]:
    """Return k queries farthest from centroid in FULL scaled feature space."""
    X_sub = X_scaled[idx]
    center = X_sub.mean(axis=0)
    d = np.linalg.norm(X_sub - center, axis=1)
    order = np.argsort(d)[::-1]  # descending
    rep_idx = idx[order[:min(k, len(order))]]
    return [queries[i] for i in rep_idx]

def get_pc1_extremes(cluster_df: pd.DataFrame) -> List[str]:
    """Return min/max PC1 queries within this cluster (if they exist)."""
    if cluster_df.empty:
        return []
    qmin = cluster_df.loc[cluster_df["PC1"].idxmin(), "query"]
    qmax = cluster_df.loc[cluster_df["PC1"].idxmax(), "query"]
    return [qmin, qmax] if qmin != qmax else [qmin]
def print_query_info(rep_query: str, cluster_queries: pd.Series, candidate_ref: Optional[str]) -> None:
    """Print info for one representative query and cluster-vs-candidate stats."""
    pdb_name = query_to_filename(rep_query)

    print(f"\n[INFO] Representative query: {rep_query}")
    print(f"[INFO] Representative file: {pdb_name}")

    rep_hits = (
        all_df[all_df["query"] == rep_query]
        .sort_values("rank")
        .head(5)[["reference", "Z", "rmsd"]]
    )
    print("[INFO] Top 5 DALI hits:")
    print(rep_hits.to_string(index=False))

    if candidate_ref is None:
        print("[WARN] No candidate template found for this cluster.")
        return

    summary = all_df[
        (all_df["query"].isin(cluster_queries)) &
        (all_df["ref_pdb"] == candidate_ref)
    ][["Z", "rmsd"]]

    print(f"[INFO] Cluster vs candidate template ({candidate_ref}) stats:")
    print(summary.describe())


# Print all clusters
clusters_to_print = range(N_NEW_CLUSTERS)

for c in clusters_to_print:
    mask = (full_pca_df["new_cluster"].values == c)
    idx = np.where(mask)[0]
    sub_df = full_pca_df.loc[mask].copy()
    sub_queries = sub_df["query"]

    print(f"\n{'=' * 60}")
    print(f"ANALYSIS FOR NEW CLUSTER (FULL-MATRIX): {c}")
    print(f"{'=' * 60}")
    print(f"[INFO] Cluster size: {len(sub_df)}")

    if len(sub_df) == 0:
        print("[WARN] Empty cluster (unexpected).")
        continue

    # Candidate = most common top-1 template in this cluster
    cluster_top1 = top1_ref.reindex(sub_queries).dropna()
    candidate_ref = cluster_top1.value_counts().idxmax() if not cluster_top1.empty else None

    if candidate_ref is not None:
        print(f"[INFO] Candidate template (mode of cluster top-1): {candidate_ref}")

    print("\n[INFO] Cluster top-1 template composition (top 10):")
    print(cluster_top1.value_counts().head(10))

    # ---- Always print 1 main representative (closest to centroid) ----
    reps = [get_k_nearest_to_centroid(idx, 1)[0]]

    # ---- Optionally add more representatives ----
    if not PRINT_MAIN_ONLY:
        reps += get_k_nearest_to_centroid(idx, N_REPS_PER_CLUSTER)
        reps += get_k_farthest_from_centroid(idx, N_FARTHEST_PER_CLUSTER)
        if INCLUDE_PC_EXTREMES:
            reps += get_pc1_extremes(sub_df)

    # De-duplicate while preserving order
    seen = set()
    reps = [q for q in reps if not (q in seen or seen.add(q))]

    print(f"\n[INFO] Printing {len(reps)} representatives for cluster {c}...\n")

    for i, rep_query in enumerate(reps):
        print("-" * 60)
        if i == 0:
            print("[INFO] MAIN representative (closest to centroid)")
        print_query_info(rep_query, sub_queries, candidate_ref)
