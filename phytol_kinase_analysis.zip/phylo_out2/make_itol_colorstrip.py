#!/usr/bin/env python3
from __future__ import annotations

import re
from pathlib import Path
from collections import defaultdict

# =========================
# EDIT PATHS
# =========================
REP_FASTA = Path(r"./rep_cdhit_70.fasta")
OUT_ITOL  = Path(r"./itol_cluster_colorstrip.txt")

# If your headers encode cluster like "...|cluster=2" or "... cluster=2", adjust this regex:
CLUSTER_RE = re.compile(r"(?:cluster=|cluster:)(\d+)")

def parse_fasta_headers(fp: Path):
    headers = []
    for line in fp.read_text(encoding="utf-8", errors="ignore").splitlines():
        if line.startswith(">"):
            headers.append(line[1:].strip())
    return headers

def main():
    if not REP_FASTA.exists():
        raise FileNotFoundError(f"Missing: {REP_FASTA}")

    headers = parse_fasta_headers(REP_FASTA)

    # Map tip label (what FastTree uses) -> cluster
    # FastTree uses the full header up to first whitespace as sequence name.
    tip_to_cluster = {}
    missing = 0
    for h in headers:
        tip = h.split()[0]
        m = CLUSTER_RE.search(h)
        if not m:
            missing += 1
            continue
        tip_to_cluster[tip] = int(m.group(1))

    if not tip_to_cluster:
        raise RuntimeError(
            "No cluster labels found in headers. "
            "Check CLUSTER_RE and confirm your FASTA headers contain 'cluster=...'."
        )

    clusters = sorted(set(tip_to_cluster.values()))
    print(f"[INFO] Tips with cluster labels: {len(tip_to_cluster)}/{len(headers)}")
    print(f"[INFO] Distinct clusters found: {clusters}")

    # iTOL DATASET_COLORSTRIP requires a color per label.
    # We'll assign a fixed palette (repeatable). You can customize later.
    palette = [
        "#1f77b4","#ff7f0e","#2ca02c","#d62728","#9467bd",
        "#8c564b","#e377c2","#7f7f7f","#bcbd22","#17becf"
    ]
    cluster_to_color = {c: palette[i % len(palette)] for i, c in enumerate(clusters)}

    lines = []
    lines.append("DATASET_COLORSTRIP")
    lines.append("SEPARATOR\tTAB")
    lines.append("DATASET_LABEL\tStructural_cluster")
    lines.append("COLOR\t#000000")
    lines.append("LEGEND_TITLE\tStructural cluster")
    lines.append("LEGEND_SHAPES\t" + "\t".join(["1"] * len(clusters)))
    lines.append("LEGEND_COLORS\t" + "\t".join(cluster_to_color[c] for c in clusters))
    lines.append("LEGEND_LABELS\t" + "\t".join([f"cluster_{c}" for c in clusters]))
    lines.append("DATA")

    # DATA format: tip_label <tab> color <tab> label
    for tip, c in tip_to_cluster.items():
        lines.append(f"{tip}\t{cluster_to_color[c]}\tcluster_{c}")

    OUT_ITOL.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[INFO] Wrote iTOL annotation file: {OUT_ITOL}")
    if missing:
        print(f"[WARN] {missing} sequences had no cluster label in header.")

if __name__ == "__main__":
    main()
