#!/usr/bin/env python3
from __future__ import annotations

import random
import re
from collections import Counter
from pathlib import Path
from typing import Dict, Optional, List, Set

import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
import pandas as pd
from Bio import Phylo

# ----------------------------
# CONFIG
# ----------------------------
TREE_NWK = Path(".//rep_cdhit_70__fasttree.nwk")
MAP_TSV  = Path("./accession_to_cluster.tsv")   # from build_tree_inputs.py
OUTPNG   = Path("./tree_pruned_colored_rerooted.png")
OUTTSV   = Path("./tree_cluster_coherence.tsv")

# Pruning: keep at most this many tips per cluster in the plot (set None to keep all)
MAX_TIPS_PER_CLUSTER = 250
RANDOM_SEED = 7

# Colors for clusters (single source of truth)
CLUSTER_TO_COLOR = {
    0: "tab:blue",
    1: "tab:orange",
    2: "tab:green",
    3: "tab:red",
    4: "tab:purple",
}

# Tip label rendering (WARNING: can get unreadable on large trees)
SHOW_TIP_LABELS = False          # set True to draw labels on the right
TIP_LABEL_ACCESSION_ONLY = True  # if True, label with accession; else full tip name
TIP_LABEL_FONTSIZE = 26          # <- make tip labels 22 as requested
TIP_LABEL_XPAD = 0.02            # branch-length units; increase if labels overlap tips

# Rooting options:
# 1) If you know an accession that is clearly in the "AFB4-like" cluster, put it here as outgroup
OUTGROUP_ACCESSION: Optional[str] = None
# 2) Or root using any one random tip from this cluster id as outgroup (e.g. AFB4-like cluster id)
OUTGROUP_CLUSTER: Optional[int] = None
# 3) Otherwise: midpoint rooting is used
USE_MIDPOINT_ROOTING = True

# ----------------------------
# PLOT STYLE
# ----------------------------
FONT_SIZE = 28

plt.rcParams.update({
    "font.size": FONT_SIZE,
    "axes.titlesize": FONT_SIZE,
    "axes.labelsize": FONT_SIZE,
    "xtick.labelsize": FONT_SIZE,
    "ytick.labelsize": FONT_SIZE,
    "legend.fontsize": FONT_SIZE,
    "figure.titlesize": FONT_SIZE,
})

# Visual tuning (not fonts)
TIP_MARKER_S = 800          # scatter area (points^2) for tip dots
SPINE_LW = 1.5              # frame thickness
LEGEND_MARKERSIZE = 14      # legend marker size (not font)
BRANCH_LW = 1.0
BRANCH_ALPHA = 0.8


# ----------------------------
# Helpers
# ----------------------------
_re_sptr = re.compile(r"^(sp|tr)\|([^|]+)\|")
_re_cluster = re.compile(r"(?:^|[|])cluster=([0-9]+)(?:$|[|])")

def extract_accession(label: str) -> str:
    """
    Robustly extract UniProt accession from a FASTA/tree label.
    Handles:
      sp|Q12382|DGK1_YEAST|cluster=1
      tr|A0A0F8CPY4|A0A0F8CPY4_CERFI|cluster=2
      A0A0F8CPY4|cluster=2
      A0A0F8CPY4
    """
    if label is None:
        return ""
    m = _re_sptr.match(label)
    if m:
        return m.group(2)
    tok = label.split()[0]
    return tok.split("|")[0]

def load_accession_to_cluster(tsv: Path) -> Dict[str, int]:
    df = pd.read_csv(tsv, sep="\t")
    col_acc = "accession" if "accession" in df.columns else df.columns[0]
    col_clu = "cluster" if "cluster" in df.columns else df.columns[1]
    out: Dict[str, int] = {}
    for _, r in df.iterrows():
        out[str(r[col_acc])] = int(r[col_clu])
    return out

def tip_to_cluster(tip_name: str, acc2clu: Dict[str, int]) -> Optional[int]:
    if not tip_name:
        return None
    m = _re_cluster.search(tip_name)
    if m:
        return int(m.group(1))
    acc = extract_accession(tip_name)
    return acc2clu.get(acc)

def choose_outgroup(tree, tip_cluster: Dict[str, int]) -> Optional[str]:
    if OUTGROUP_ACCESSION:
        return OUTGROUP_ACCESSION

    if OUTGROUP_CLUSTER is not None:
        candidates = [
            t.name for t in tree.get_terminals()
            if t.name in tip_cluster and tip_cluster[t.name] == OUTGROUP_CLUSTER
        ]
        if candidates:
            random.seed(RANDOM_SEED)
            return random.choice(candidates)

    return None

def prune_to_max_per_cluster(tree, tip_cluster: Dict[str, int],
                             max_per_cluster: Optional[int]) -> None:
    if max_per_cluster is None:
        return
    random.seed(RANDOM_SEED)

    by_c: Dict[int, List[str]] = {}
    for t in tree.get_terminals():
        c = tip_cluster.get(t.name)
        if c is None:
            continue
        by_c.setdefault(c, []).append(t.name)

    keep: Set[str] = set()
    for c, names in by_c.items():
        if len(names) <= max_per_cluster:
            keep.update(names)
        else:
            keep.update(random.sample(names, max_per_cluster))

    for term in list(tree.get_terminals()):
        if term.name not in keep:
            tree.prune(term)

def compute_depths(tree) -> Dict[Phylo.BaseTree.Clade, float]:
    return tree.depths(unit_branch_lengths=False)

def draw_custom_phylogram(
    ax,
    tree,
    tip_cluster: Dict[str, int],
    cluster_to_color: Dict[int, str],
    show_tip_labels: bool = False,
    accession_only: bool = True,
    label_fontsize: int = 22,
    label_xpad: float = 0.02,
) -> None:
    """
    Draw a rectangular phylogram where every parent->child edge is a single L-shaped polyline.
    This eliminates the small "gaps" that appear when horizontal and vertical branches are drawn
    as separate primitives.
    """
    depths = compute_depths(tree)
    tips = tree.get_terminals()

    # y positions for tips (order)
    y_tip = {t: i for i, t in enumerate(tips)}

    # y position for every clade = mean of child y's (rectangular phylogram)
    y_clade: Dict[Phylo.BaseTree.Clade, float] = {}

    def assign_y(clade) -> float:
        if clade in y_clade:
            return y_clade[clade]
        if clade.is_terminal():
            y_clade[clade] = float(y_tip[clade])
            return y_clade[clade]
        ys = [assign_y(ch) for ch in clade.clades]
        y_clade[clade] = sum(ys) / len(ys) if ys else 0.0
        return y_clade[clade]

    assign_y(tree.root)

    # Build L-shaped polylines: (x_parent, y_parent) -> (x_parent, y_child) -> (x_child, y_child)
    segments = []

    def add_edges(parent):
        x_p = depths.get(parent, 0.0)
        y_p = y_clade.get(parent, 0.0)
        for ch in parent.clades:
            x_c = depths.get(ch, x_p)
            y_c = y_clade.get(ch, y_p)

            # One single L-shaped polyline for this edge
            segments.append([(x_p, y_p), (x_p, y_c), (x_c, y_c)])

            if not ch.is_terminal():
                add_edges(ch)

    add_edges(tree.root)

    # Frame styling
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(SPINE_LW)

    # Branches: pure black, continuous corners
    lc = LineCollection(
        segments,
        colors="black",
        linewidths=BRANCH_LW,
        alpha=BRANCH_ALPHA,
        capstyle="round",
        joinstyle="round",
        antialiased=True,
        zorder=1,
    )
    ax.add_collection(lc)

    # Tips as colored dots
    xs, ys, cs = [], [], []
    for t in tips:
        xs.append(depths.get(t, 0.0))
        ys.append(y_tip[t])
        c_id = tip_cluster.get(t.name)
        cs.append(cluster_to_color.get(c_id, "tab:gray"))

    ax.scatter(
        xs, ys,
        s=TIP_MARKER_S,
        c=cs,
        edgecolors="black",
        linewidths=0.5,
        zorder=3
    )

    # Optional: colored tip labels
    if show_tip_labels:
        for t, x, yy, col in zip(tips, xs, ys, cs):
            if not t.name:
                continue
            label = extract_accession(t.name) if accession_only else t.name
            ax.text(
                x + label_xpad,
                yy,
                label,
                va="center",
                ha="left",
                fontsize=label_fontsize,
                color=col,
                zorder=4,
                clip_on=False,
            )

    ax.set_xlabel("branch length")
    ax.set_ylabel("tips (order)")
    ax.set_yticks([])
    ax.tick_params(axis="both", labelsize=FONT_SIZE)

    # IMPORTANT: do not crop left side; always include root at x=0
    max_x = max(depths.values()) if depths else (max(xs) if xs else 1.0)
    ax.set_xlim(0.0, max_x + 0.1)
    pad = max(10, int(0.03 * len(tips)))  # ~3% of tips, at least 10
    ax.set_ylim(-pad, len(tips) - 1 + pad)
    ax.margins(x=0.04)
    ax.margins(y=0.04)


def cluster_coherence(tree, tip_cluster: Dict[str, int]) -> pd.DataFrame:
    tips = tree.get_terminals()
    name_to_tip = {t.name: t for t in tips}

    clusters = sorted(set(tip_cluster.values()))
    rows = []

    for c in clusters:
        c_names = [n for n, cc in tip_cluster.items() if cc == c and n in name_to_tip]
        if len(c_names) < 2:
            continue

        mrca = tree.common_ancestor([name_to_tip[n] for n in c_names])
        mrca_tips = [t.name for t in mrca.get_terminals()]
        in_cluster = sum(1 for n in mrca_tips if tip_cluster.get(n) == c)
        purity = in_cluster / max(1, len(mrca_tips))

        rows.append({
            "cluster": c,
            "cluster_tips_in_tree": len(c_names),
            "mrca_total_tips": len(mrca_tips),
            "mrca_in_cluster": in_cluster,
            "mrca_purity": purity,
            "strict_monophyletic": (in_cluster == len(mrca_tips) and len(c_names) == len(mrca_tips)),
        })

    return pd.DataFrame(rows).sort_values(
        ["mrca_purity", "cluster_tips_in_tree"],
        ascending=[False, False]
    )

def main():
    if not TREE_NWK.exists():
        raise RuntimeError(f"Tree not found: {TREE_NWK}")
    if not MAP_TSV.exists():
        raise RuntimeError(f"Map TSV not found: {MAP_TSV}")

    acc2clu = load_accession_to_cluster(MAP_TSV)
    tree = Phylo.read(str(TREE_NWK), "newick")

    # Map terminal-name -> cluster
    tip_cluster: Dict[str, int] = {}
    for t in tree.get_terminals():
        c = tip_to_cluster(t.name, acc2clu)
        if c is not None:
            tip_cluster[t.name] = c

    print(f"[INFO] Tips in tree: {len(tree.get_terminals())}", flush=True)
    print(f"[INFO] Tips with cluster labels: {len(tip_cluster)}", flush=True)
    print("[INFO] Cluster counts (tree tips):", Counter(tip_cluster.values()), flush=True)

    # Rooting
    outgroup_name = choose_outgroup(tree, tip_cluster)
    if outgroup_name is not None:
        out = None
        for t in tree.get_terminals():
            if t.name == outgroup_name:
                out = t
                break
        if out is None:
            raise RuntimeError(f"Outgroup '{outgroup_name}' not found as a terminal name in the tree.")
        tree.root_with_outgroup(out)
        print(f"[INFO] Rooted with outgroup: {outgroup_name}", flush=True)
    elif USE_MIDPOINT_ROOTING:
        tree.root_at_midpoint()
        print("[INFO] Rooted at midpoint.", flush=True)
    else:
        print("[INFO] Using existing root.", flush=True)

    tree.ladderize(reverse=True)

    # Prune for readability
    prune_to_max_per_cluster(tree, tip_cluster, MAX_TIPS_PER_CLUSTER)

    # Recompute tip_cluster after pruning
    tip_cluster_pruned = {t.name: tip_cluster[t.name] for t in tree.get_terminals() if t.name in tip_cluster}
    counts = Counter(tip_cluster_pruned.values())

    # Score coherence
    df_coh = cluster_coherence(tree, tip_cluster_pruned)
    df_coh.to_csv(OUTTSV, sep="\t", index=False)
    print(f"[INFO] Wrote coherence TSV: {OUTTSV}", flush=True)
    if not df_coh.empty:
        print(df_coh.to_string(index=False), flush=True)

    # Plot (tall figure for readability)
    fig = plt.figure(figsize=(18, 24), dpi=300)
    ax = fig.add_subplot(1, 1, 1)

    draw_custom_phylogram(
        ax,
        tree,
        tip_cluster_pruned,
        cluster_to_color=CLUSTER_TO_COLOR,
        show_tip_labels=SHOW_TIP_LABELS,
        accession_only=TIP_LABEL_ACCESSION_ONLY,
        label_fontsize=TIP_LABEL_FONTSIZE,
        label_xpad=TIP_LABEL_XPAD,
    )

    # Legend
    legend_lines = []
    legend_labels = []
    ordered_clusters = sorted(counts)

    for c in ordered_clusters:
        col = CLUSTER_TO_COLOR.get(c, "tab:gray")
        legend_lines.append(
            plt.Line2D(
                [0], [0],
                marker="o",
                linestyle="",
                markersize=LEGEND_MARKERSIZE,
                markerfacecolor=col,
                markeredgecolor=col,
                color=col,
            )
        )
        legend_labels.append(f"cluster {c}")

    leg = ax.legend(
        legend_lines,
        legend_labels,
        loc="upper right",
        frameon=True,
        fontsize=FONT_SIZE,
    )

    # Optional: color the legend text to match each cluster marker
    for txt, c in zip(leg.get_texts(), ordered_clusters):
        txt.set_color(CLUSTER_TO_COLOR.get(c, "tab:gray"))

    ax.set_title("FastTree phylogram", pad=20)
    fig.tight_layout()
    fig.savefig(OUTPNG)
    print(f"[INFO] Wrote plot: {OUTPNG}", flush=True)

if __name__ == "__main__":
    main()
