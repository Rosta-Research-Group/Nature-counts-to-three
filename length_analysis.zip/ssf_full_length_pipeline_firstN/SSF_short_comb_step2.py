# -*- coding: utf-8 -*-
import os
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ======================= PATHS =======================
BASE = r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\check_length"
OUT_DIR = Path(BASE) / "ssf_full_length_pipeline_firstN"
LEN_FILE = OUT_DIR / "ssf_uniprot_lengths_firstN.csv"
SUM_BY_SSF = OUT_DIR / "ssf_uniprot_length_summary_by_ssf.csv"
SUM_BY_RXN_ION = OUT_DIR / "ssf_uniprot_length_summary_by_rxn_ion.csv"

# =================== READ DATA =======================
if not LEN_FILE.exists():
    raise SystemExit(f"Row-level file not found: {LEN_FILE}")

df = pd.read_csv(LEN_FILE)
# Expect columns: UniProt, UniProt_length, SSF_ID, SF, Reaction, Extra_Ions
req = {"UniProt","UniProt_length","SSF_ID","SF","Reaction","Extra_Ions"}
missing = req - set(df.columns)
if missing:
    raise SystemExit(f"Missing columns in {LEN_FILE}: {missing}")

# Clean types
df["UniProt_length"] = pd.to_numeric(df["UniProt_length"], errors="coerce")
df["Extra_Ions"] = pd.to_numeric(df["Extra_Ions"], errors="coerce")
df["SF"] = df["SF"].astype(str).str.strip()
df["Reaction"] = df["Reaction"].astype(str).str.strip()

# Map old labels to nicer ones
_rxn_map = {
    "P": "Pi",
    "PP": "PPi",
    "Pi": "Pi",
    "PPi": "PPi"
}
df["Reaction"] = df["Reaction"].map(lambda x: _rxn_map.get(x, x))

print("[INFO] Rows:", len(df), "| SFs:", df["SF"].nunique(),
      "| SSFs:", df["SSF_ID"].nunique(), "| Reactions:", df["Reaction"].unique().tolist())

# Optional: read summaries (if you want to inspect them)
if SUM_BY_SSF.exists():
    s1 = pd.read_csv(SUM_BY_SSF)
    print("\n=== Summary by SSF (head) ===")
    print(s1.head(8).to_string(index=False))
if SUM_BY_RXN_ION.exists():
    s2 = pd.read_csv(SUM_BY_RXN_ION)
    print("\n=== Summary by Reaction × Ions (head) ===")
    print(s2.head(8).to_string(index=False))

# ======================== PLOTS ========================
def _ion_color(n):
    # same palette idea as before
    try:
        n = int(round(n if pd.notna(n) else 0))
    except Exception:
        n = 0
    if n <= 0: return "#7f7f7f"
    if n == 1: return "#1f77b4"
    if n == 2: return "#ff7f0e"
    if n == 3: return "#2ca02c"
    return "#d62728"

def plot_superfamilies_one_kind(df_in, kind="P",
                                title_prefix="Full Protein Length by Superfamily (UniProt)",
                                figsize=(30, 16)):
    from matplotlib.lines import Line2D
    sub = df_in[df_in["Reaction"] == kind].copy()
    fig, ax = plt.subplots(figsize=figsize, constrained_layout=True)
    if sub.empty:
        ax.axis("off"); ax.set_title(f"No data for {kind}")
        return fig
    # order SFs by median length
    med = sub.groupby("SF")["UniProt_length"].median().sort_values(ascending=False)
    order_sf = med.index.tolist()
    pos  = np.arange(len(order_sf))
    data = [sub.loc[sub["SF"]==sf, "UniProt_length"].dropna().values for sf in order_sf]

    ax.boxplot(
        data, positions=pos, widths=0.7, vert=True, patch_artist=True,
        boxprops=dict(facecolor="#F2F2F2", edgecolor="#444", linewidth=2.0),
        medianprops=dict(color="black", linewidth=2.2),
        whiskerprops=dict(color="#444", linewidth=1.8),
        capprops=dict(color="#444", linewidth=1.8),
        flierprops=dict(marker="o", markersize=5, markerfacecolor="black", alpha=0.5)
    )

    # average ion count per SF for coloring x-tick labels
    avg_ions = sub.groupby("SF")["Extra_Ions"].mean().reindex(order_sf).fillna(0)
    ax.set_xticks(pos)
    ax.set_xticklabels(order_sf, rotation=60, ha="right", fontsize=16)
    for tick, sf in zip(ax.get_xticklabels(), order_sf):
        tick.set_color(_ion_color(avg_ions.loc[sf]))

    ax.set_ylabel("Full protein length (UniProt residues)", fontsize=18)
    ax.set_title(f"{title_prefix} — {kind}", pad=8, fontsize=20)
    ax.tick_params(axis="y", labelsize=16)
    ax.set_ylim(bottom=0)

    legend_elems = [
        Line2D([0],[0], color=_ion_color(v), lw=0, marker='s', markersize=10, label=lab)
        for v, lab in [(1,"1"),(2,"2"),(3,"3")]
    ]
    ax.legend(handles=legend_elems, loc="upper left",
              bbox_to_anchor=(1.01, 1), frameon=False, title="Avg active-site ions")
    return fig

# Reaction-level boxplot (P vs PP)
order_rxn = (df.groupby("Reaction")["UniProt_length"]
             .mean().sort_values(ascending=False).index.tolist())
fig1 = plt.figure(figsize=(8,6))
plt.boxplot([df.loc[df["Reaction"]==r, "UniProt_length"].dropna() for r in order_rxn],
            labels=order_rxn, vert=True)
plt.title("Full Protein Length Distribution by Reaction (UniProt)")
plt.xlabel("Reaction"); plt.ylabel("Full protein length (residues)")
plt.tight_layout()
fig1_path = OUT_DIR / "figure_full_length_by_reaction.png"
plt.savefig(fig1_path, dpi=220)
plt.close(fig1)
print("[SAVE]", fig1_path)

# Ion-level boxplot (1/2/3…)
ion_levels = sorted([x for x in df["Extra_Ions"].dropna().unique()])
fig2 = plt.figure(figsize=(8,6))
plt.boxplot([df.loc[df["Extra_Ions"]==k, "UniProt_length"].dropna() for k in ion_levels],
            labels=[str(int(k)) for k in ion_levels], vert=True)
plt.title("Full Protein Length Distribution by Active-Site Ion Count (UniProt)")
plt.xlabel("Number of active-site ions"); plt.ylabel("Full protein length (residues)")
plt.tight_layout()
fig2_path = OUT_DIR / "figure_full_length_by_ioncount.png"
plt.savefig(fig2_path, dpi=220)
plt.close(fig2)
print("[SAVE]", fig2_path)

# Per-superfamily plots for P and PP (with colored SF ticks by avg ion count)
with plt.rc_context({
    "font.size": 18, "axes.titlesize": 20, "axes.labelsize": 18,
    "ytick.labelsize": 16, "legend.fontsize": 16,
    "figure.constrained_layout.use": True
}):
    figP = plot_superfamilies_one_kind(df, kind="Pi",
                                       title_prefix="Full Protein Length by Superfamily (UniProt)",
                                       figsize=(30, 16))
    figP_path = OUT_DIR / "figure_full_length_by_sf_P.png"
    plt.savefig(figP_path, dpi=200); plt.close(figP); print("[SAVE]", figP_path)

    figPP = plot_superfamilies_one_kind(df, kind="PPi",
                                        title_prefix="Full Protein Length by Superfamily (UniProt)",
                                        figsize=(30, 16))
    figPP_path = OUT_DIR / "figure_full_length_by_sf_PP.png"
    plt.savefig(figPP_path, dpi=200); plt.close(figPP); print("[SAVE]", figPP_path)

# ============== Inspect min / max per Reaction × Ion ==============
if not df.empty:
    grp = df.dropna(subset=["UniProt_length"]).copy()
    if not grp.empty:
        idx_min = grp.groupby(["Reaction","Extra_Ions"])["UniProt_length"].idxmin()
        idx_max = grp.groupby(["Reaction","Extra_Ions"])["UniProt_length"].idxmax()
        min_records = grp.loc[idx_min, ["Reaction","Extra_Ions","SF","UniProt","UniProt_length"]] \
                         .sort_values(["Reaction","Extra_Ions"])
        max_records = grp.loc[idx_max, ["Reaction","Extra_Ions","SF","UniProt","UniProt_length"]] \
                         .sort_values(["Reaction","Extra_Ions"])

        print("\n--- Shortest protein(s) per Reaction × Ion ---")
        print(min_records.to_string(index=False))
        print("\n--- Longest protein(s) per Reaction × Ion ---")
        print(max_records.to_string(index=False))

        min_csv = OUT_DIR / "full_length_min_by_rxn_ion.csv"
        max_csv = OUT_DIR / "full_length_max_by_rxn_ion.csv"
        min_records.to_csv(min_csv, index=False)
        max_records.to_csv(max_csv, index=False)
        print("[SAVE]", min_csv)
        print("[SAVE]", max_csv)

print("\n[OK] Plots and tables saved in:", OUT_DIR)
