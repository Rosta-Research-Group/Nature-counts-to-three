# -*- coding: utf-8 -*-
"""
Extract sequences for your SSFs from local UniProt FASTA archives (Swiss-Prot + TrEMBL).
# In the folder you want the files these commands download uniprot database:
curl.exe -L -C - -o uniprot_sprot.fasta.gz  "https://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz"
curl.exe -L -C - -o uniprot_trembl.fasta.gz "https://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_trembl.fasta.gz"

Inputs:
  - cache_ssf_uniprot_lists/{SSF}.tsv   (one UniProt accession per line; created by your "fetch" step)
  - uniprot_sprot.fasta.gz              (Swiss-Prot; you downloaded it)
  - uniprot_trembl.fasta.gz             (TrEMBL; you downloaded it)

Outputs (resumable):
  - ssf_fasta/SSF_<ID>.fasta            (one per SSF; appended)
  - ssf_uniprot_lengths_from_local.csv  (accession lengths + SSF/SF/Reaction/Ions)

Tips:
  - You can limit per-SSF to the first N accessions (LIMIT_PER_SSF) for quick testing.
  - Safe to re-run; already-processed accessions are skipped using the lengths CSV.
"""

import os, re, gzip
from pathlib import Path
import pandas as pd
import numpy as np

# ===================== USER CONFIG =====================
BASE       = r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\check_length"
MAP_CSV    = os.path.join(BASE, "reps_rxn_metalNO.csv")                # curated mapping (has SSF + meta)
FETCH_DIR  = Path(BASE) / "ssf_full_length_pipeline" / "cache_ssf_uniprot_lists"
FASTA_DIR  = Path(BASE)                                                # where you put the big FASTAs
SPROT_GZ   = FASTA_DIR / "uniprot_sprot.fasta.gz"
TREMBL_GZ  = FASTA_DIR / "uniprot_trembl.fasta.gz"

OUT_DIR    = Path(BASE) / "ssf_from_local_uniprot"
OUT_FASTA  = OUT_DIR / "ssf_fasta"
LEN_FILE   = OUT_DIR / "ssf_uniprot_lengths_from_local.csv"            # resume index

# Limit per SSF to get quick results (None for all; e.g., 100 for first 100)
LIMIT_PER_SSF = None  # set to 100 for quick test, then None for full run

# ======================================================

OUT_DIR.mkdir(parents=True, exist_ok=True)
OUT_FASTA.mkdir(parents=True, exist_ok=True)

def norm_cols(cols):
    return (cols.astype(str)
                .str.replace("\ufeff","",regex=False)
                .str.strip().str.lower().str.replace(r"\s+"," ",regex=True))

def normalise_rxn(s):
    s2 = (s.astype(str).str.upper().str.replace(r"\s+","",regex=True))
    return np.where(s2.str.contains("PP"), "PP", "P")

def read_mapping_with_ssf(map_csv: str) -> pd.DataFrame:
    m = pd.read_csv(map_csv, sep=None, engine="python", encoding="utf-8-sig")
    m.columns = norm_cols(m.columns)
    def pick(df, opts, required=True):
        for o in opts:
            if o in df.columns: return o
        if required: raise SystemExit(f"Missing col; need one of {opts}\nHave: {list(df.columns)}")
        return None
    c_rxn = pick(m, ["reaction","pi_pp","phosphate_type"])
    c_sf  = pick(m, ["sf","superfamily","sf name","superfamily name"])
    c_ion = pick(m, ["extraions","extra_ions","metals","n_metals"])
    c_ssf = pick(m, ["ssf","ssf_id","ssf id","scop_superfamily","superfamily (ssf)"])
    m = m.rename(columns={c_rxn:"Reaction", c_sf:"SF", c_ion:"Extra_Ions", c_ssf:"SSF_ID"})
    m["ReactionPP"] = normalise_rxn(m["Reaction"])
    m["Extra_Ions"] = pd.to_numeric(m["Extra_Ions"], errors="coerce")
    m["SF"]         = m["SF"].astype(str).str.strip()
    m["SSF_ID"]     = m["SSF_ID"].astype(str).str.strip()
    m = m[m["SSF_ID"].str.match(r"^SSF\d+$", na=False)].copy()
    return m

def load_ssf_accessions(fetch_dir: Path, limit_per_ssf=None):
    """
    Read cached lists cache_ssf_uniprot_lists/{SSF}.tsv and build:
        - ssf_to_accs: dict SSF_ID -> [acc, ...] (respects LIMIT_PER_SSF)
        - acc_to_ssfs: dict acc -> set([SSF_ID, ...])  (for fast lookup)
    """
    if not fetch_dir.exists():
        raise SystemExit(f"Missing cached SSF lists folder: {fetch_dir}")
    ssf_to_accs = {}
    acc_to_ssfs = {}
    files = sorted(fetch_dir.glob("SSF*.tsv"))
    if not files:
        raise SystemExit(f"No SSF lists found in {fetch_dir}. Run your 'fetch' step or copy files here.")

    for fp in files:
        ssf_id = fp.stem  # "SSFxxxxx"
        try:
            df = pd.read_csv(fp)
            accs = df.iloc[:,0].dropna().astype(str).tolist()
        except Exception:
            df = pd.read_csv(fp, sep="\t", header=0)
            accs = df.iloc[:,0].dropna().astype(str).tolist()

        if limit_per_ssf is not None:
            accs = accs[:int(limit_per_ssf)]
        if not accs:
            continue
        ssf_to_accs[ssf_id] = accs
        for a in accs:
            acc_to_ssfs.setdefault(a, set()).add(ssf_id)

    if not ssf_to_accs:
        raise SystemExit("No accessions loaded from cached SSF lists (after applying limit).")
    return ssf_to_accs, acc_to_ssfs

def read_resume_index(len_file: Path):
    """Return set of UniProt already processed (so we can resume)."""
    if not len_file.exists():
        return set()
    try:
        df = pd.read_csv(len_file, usecols=["UniProt"])
        return set(df["UniProt"].astype(str))
    except Exception:
        return set()

def open_fasta_handle_for_ssf(ssf_id: str):
    path = OUT_FASTA / f"SSF_{ssf_id}.fasta"
    # append mode so it's resumable
    return open(path, "a", encoding="utf-8"), path

_acc_regex = re.compile(r"^>(\S+)")
def parse_accession_from_header(header: str) -> str | None:
    """
    Robustly extract UniProt accession from FASTA header lines like:
      >sp|P12345|PROT_HUMAN ...
      >tr|A0A123ABC4|...
      >A0A123ABC4 some text
    """
    h = header.strip()
    if not h.startswith(">"):
        return None
    # pipe format: sp|ACC| or tr|ACC|
    if "|" in h:
        parts = h[1:].split("|", 3)
        if len(parts) >= 2:
            return parts[1]
    # fallback: first token after ">"
    m = _acc_regex.match(h)
    if m:
        tok = m.group(1)
        # If tok still contains pipes, try taking middle
        if "|" in tok:
            t2 = tok.split("|")
            if len(t2) >= 2:
                return t2[1]
        return tok
    return None

def stream_fasta_gz(gz_path: Path):
    """
    Generator yielding (header, seq) for each record in a gzipped FASTA.
    Streams line-by-line; keeps only one record in memory.
    """
    with gzip.open(gz_path, "rt", encoding="utf-8", newline="") as fh:
        header = None
        seq_chunks = []
        for ln in fh:
            if ln.startswith(">"):
                if header is not None:
                    yield header, "".join(seq_chunks)
                header = ln.rstrip("\n")
                seq_chunks = []
            else:
                seq_chunks.append(ln.strip())
        if header is not None:
            yield header, "".join(seq_chunks)

def main():
    # Mapping table (for meta)
    m = read_mapping_with_ssf(MAP_CSV)
    meta_by_ssf = (m.groupby("SSF_ID", dropna=False)
                     .agg(SF=("SF","first"),
                          Reaction=("ReactionPP","first"),
                          Extra_Ions=("Extra_Ions","first"))
                     .to_dict(orient="index"))

    # Load cached SSF accession lists
    ssf_to_accs, acc_to_ssfs = load_ssf_accessions(FETCH_DIR, limit_per_ssf=LIMIT_PER_SSF)
    print(f"[INFO] SSFs to extract: {len(ssf_to_accs)} "
          f"(union accessions: {sum(len(v) for v in ssf_to_accs.values()):,} "
          f"{'limited per SSF' if LIMIT_PER_SSF else 'total'})")

    # Resume index
    already = read_resume_index(LEN_FILE)
    if already:
        print(f"[RESUME] {len(already):,} accessions already processed (from {LEN_FILE.name}).")

    # Open one file per SSF on demand (and keep open)
    open_handles = {}  # ssf_id -> (fh, path)
    lengths_rows = []  # buffered rows to append periodically
    flush_every = 5000

    def ensure_handle(ssf_id):
        if ssf_id not in open_handles:
            fh, p = open_fasta_handle_for_ssf(ssf_id)
            open_handles[ssf_id] = (fh, p)
        return open_handles[ssf_id][0]

    def append_lengths_rows(rows):
        df = pd.DataFrame(rows, columns=["UniProt","UniProt_length","SSF_ID","SF","Reaction","Extra_Ions"])
        write_header = not LEN_FILE.exists()
        df.to_csv(LEN_FILE, mode="a", header=write_header, index=False)

    # Make a fast membership test set (only for IDs not yet processed)
    todo_accs = set(a for a in acc_to_ssfs.keys() if a not in already)
    print(f"[INFO] Accessions to search in FASTA: {len(todo_accs):,}")

    if len(todo_accs) == 0:
        print("[DONE] Nothing to do (all accessions already extracted).")
        return

    scanned = 0
    matched = 0

    def process_stream(gz_path: Path, label: str):
        nonlocal scanned, matched, lengths_rows
        if not gz_path.exists():
            print(f"[WARN] {label} file missing: {gz_path}")
            return
        print(f"[SCAN] {label}: {gz_path.name}")
        for header, seq in stream_fasta_gz(gz_path):
            scanned += 1
            acc = parse_accession_from_header(header)
            if (acc is None) or (acc not in todo_accs):
                continue
            # match: may belong to multiple SSFs
            ssfs = acc_to_ssfs.get(acc, ())
            L = len(seq)
            for ssf_id in ssfs:
                fh = ensure_handle(ssf_id)
                # write FASTA record
                fh.write(f"{header}\n")
                # wrap sequence 60 chars/line for readability
                for i in range(0, L, 60):
                    fh.write(seq[i:i+60] + "\n")
                matched += 1
                # lengths meta
                meta = meta_by_ssf.get(ssf_id, {"SF": ssf_id, "Reaction": "P", "Extra_Ions": np.nan})
                lengths_rows.append((acc, L, ssf_id, meta.get("SF"), meta.get("Reaction"), meta.get("Extra_Ions")))
            # mark as done so we don't duplicate if same acc appears in SP+TR
            todo_accs.discard(acc)

            # periodic flush for large runs
            if len(lengths_rows) >= flush_every:
                append_lengths_rows(lengths_rows)
                lengths_rows = []
                print(f"   [PROGRESS] scanned={scanned:,} | matched={matched:,} | remaining={len(todo_accs):,}")

        print(f"[DONE] {label} scan complete: scanned={scanned:,}, matched={matched:,}, remaining={len(todo_accs):,}")

    # Stream Swiss-Prot then TrEMBL (if anything remains)
    process_stream(SPROT_GZ, "Swiss-Prot")
    if todo_accs:
        process_stream(TREMBL_GZ, "TrEMBL")

    # Final flush & close
    if lengths_rows:
        append_lengths_rows(lengths_rows)
        lengths_rows = []

    for ssf_id, (fh, path) in open_handles.items():
        fh.close()

    print("\n[SUMMARY]")
    print(f" - Total matched records written: {matched:,}")
    print(f" - Lengths CSV: {LEN_FILE}")
    print(f" - FASTA per SSF: {OUT_FASTA}\\SSF_<ID>.fasta")
    if LIMIT_PER_SSF:
        print(f" - NOTE: LIMIT_PER_SSF={LIMIT_PER_SSF}; rerun with None to extract all later.")

if __name__ == "__main__":
    main()
