# -*- coding: utf-8 -*-
import os, re
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ================== USER: point to your CSV ==================
LENGTHS_CSV = r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\check_length\ssf_from_local_uniprot\ssf_uniprot_lengths_from_local.csv"
OUT_DIR     = Path(LENGTHS_CSV).parent / "plots_and_tables_full_length"
OUT_DIR.mkdir(parents=True, exist_ok=True)
# =============================================================

def norm_cols(cols):
    return (cols.astype(str)
                 .str.replace("\ufeff","", regex=False)
                 .str.strip().str.lower()
                 .str.replace(r"\s+","_", regex=True))

ALIASES = {
    "sf":         ["sf","superfamily","superfamily_name","sf_name"],
    "ssf_id":     ["ssf_id","ssf","scop_superfamily","superfamily_(ssf)"],
    "reaction":   ["reaction","reactionpp","pi_pp","phosphate_type"],
    "ions":       ["extra_ions","extraions","metals","n_metals","n_ions","ions"],
    "uniprot":    ["uniprot","accession","sp_primary"],
    "length":     ["uniprot_length","length","seq_length","protein_length"]
}

def pick(df, keys, required=True):
    cols = list(df.columns)
    for k in keys:
        if k in cols: return k
    if required:
        raise SystemExit(f"Missing column; need one of {keys}\nHave: {cols}")
    return None

def normalise_rxn_pipi(s: pd.Series) -> pd.Series:
    """
    Canonicalize to 'Pi' or 'PPi'.
    Rules (case/space/punct-insensitive):
      - if contains 'pp' OR 'pyrophosphate' -> 'PPi'
      - else -> 'Pi'
    """
    def map_one(x):
        t = str(x)
        if t.strip() == "":
            return np.nan
        t2 = re.sub(r"[\s\-_/]+", "", t, flags=re.IGNORECASE)  # drop spaces/punct
        u  = t2.upper()
        if ("PP" in u) or ("PYROPHOSPHATE" in t.upper()):
            return "PPi"
        # explicit Pi variants also map to Pi
        return "Pi"
    return s.map(map_one)

# ============== Load ==============
df = pd.read_csv(LENGTHS_CSV, low_memory=False)
df.columns = norm_cols(df.columns)

cUP  = pick(df, ALIASES["uniprot"])
cLEN = pick(df, ALIASES["length"])
cRXN = pick(df, ALIASES["reaction"], required=False)
cION = pick(df, ALIASES["ions"], required=False)
cSF  = pick(df, ALIASES["sf"], required=False)
cSSF = pick(df, ALIASES["ssf_id"], required=False)

# Canonical rename
ren = {cUP:"UniProt", cLEN:"UniProt_length"}
if cRXN: ren[cRXN] = "Reaction"
if cION: ren[cION] = "Extra_Ions"
if cSF:  ren[cSF]  = "Superfamily"
if cSSF: ren[cSSF] = "SSF_ID"
df = df.rename(columns=ren)

# Clean types
df["UniProt"]        = df["UniProt"].astype(str).str.strip()
df["UniProt_length"] = pd.to_numeric(df["UniProt_length"], errors="coerce")
if "Reaction" in df.columns:
    df["Reaction"] = normalise_rxn_pipi(df["Reaction"])
if "Extra_Ions" in df.columns:
    df["Extra_Ions"] = pd.to_numeric(df["Extra_Ions"], errors="coerce")
if "Superfamily" in df.columns:
    df["Superfamily"] = df["Superfamily"].astype(str).str.strip()

# Basic filters
df = df.dropna(subset=["UniProt_length"])
df = df[df["UniProt_length"] > 0].copy()

# ============== Summaries ==============
pd.set_option("display.float_format", "{:.2f}".format)

tables = {}

# By reaction (Pi vs PPi)
if "Reaction" in df.columns:
    tables["by_reaction"] = (
        df.groupby("Reaction")["UniProt_length"]
          .agg(["count","min","max","mean","median","std"])
          .reindex(["Pi","PPi"])  # keep a consistent order if both present
    )

# By ions
if "Extra_Ions" in df.columns:
    tables["by_ions"] = (
        df.groupby("Extra_Ions")["UniProt_length"]
          .agg(["count","min","max","mean","median","std"])
          .sort_values(by="mean", ascending=False)
    )

# By reaction × ions
if {"Reaction","Extra_Ions"} <= set(df.columns):
    # ensure Reaction is Pi/PPi order in the multi-index
    t = (df.groupby(["Reaction","Extra_Ions"])["UniProt_length"]
           .agg(["count","min","max","mean","median","std"])
           .reset_index())
    cat = pd.Categorical(t["Reaction"], categories=["Pi","PPi"], ordered=True)
    t = t.assign(Reaction=cat).sort_values(["Reaction","Extra_Ions"]).set_index(["Reaction","Extra_Ions"])
    tables["by_reaction_x_ions"] = t

# By SSF / SF for reference
if "SSF_ID" in df.columns:
    tables["by_ssf"] = (
        df.groupby(["SSF_ID", *(["Superfamily"] if "Superfamily" in df.columns else [])])["UniProt_length"]
          .agg(["count","min","max","mean","median","std"])
          .reset_index()
    )

# Write Excel + CSVs
xlsx_path = OUT_DIR / "full_length_stats_summary.xlsx"
with pd.ExcelWriter(xlsx_path, engine="xlsxwriter") as xw:
    for name, t in tables.items():
        # MultiIndex to columns for Excel if needed
        if isinstance(t.index, pd.MultiIndex):
            t.reset_index().to_excel(xw, sheet_name=name[:31], index=False)
        else:
            t.to_excel(xw, sheet_name=name[:31])
for name, t in tables.items():
    (t.reset_index() if isinstance(t.index, pd.MultiIndex) else t).to_csv(OUT_DIR / f"full_length_stats_{name}.csv", index=False)
print(f"[SAVED] {xlsx_path}")
for name in tables:
    print(f"[SAVED] {OUT_DIR/f'full_length_stats_{name}.csv'}")

# ============== Plots ==============
plt.rcParams.update({"figure.constrained_layout.use": True})

def _ion_color(n):
    try:
        n = int(round(n if pd.notna(n) else 0))
    except Exception:
        n = 0
    if n <= 0: return "#7f7f7f"
    if n == 1: return "#1f77b4"
    if n == 2: return "#ff7f0e"
    if n == 3: return "#2ca02c"
    return "#d62728"

# Boxplot by Reaction (Pi vs PPi)
if "Reaction" in df.columns:
    order_rxn = [r for r in ["Pi","PPi"] if r in set(df["Reaction"])]
    if order_rxn:
        plt.figure(figsize=(8,6))
        plt.boxplot([df.loc[df["Reaction"]==r, "UniProt_length"].dropna() for r in order_rxn],
                    labels=order_rxn, vert=True)
        plt.title("Protein Length Distribution by Reaction (Pi vs PPi)")
        plt.xlabel("Reaction"); plt.ylabel("Protein Length (aa)")
        plt.tight_layout()
        outp = OUT_DIR/"plot_full_length_by_reaction_Pi_PPi.png"
        plt.savefig(outp, dpi=180); plt.close()
        print(f"[PLOT] {outp}")

# Boxplot by Extra_Ions
if "Extra_Ions" in df.columns:
    order_ion = sorted([x for x in df["Extra_Ions"].dropna().unique()])
    if order_ion:
        plt.figure(figsize=(8,6))
        plt.boxplot([df.loc[df["Extra_Ions"]==k, "UniProt_length"].dropna() for k in order_ion],
                    labels=order_ion, vert=True)
        plt.title("Protein Length Distribution by Active-Site Ion Count")
        plt.xlabel("Number of Active-Site Ions"); plt.ylabel("Protein Length (aa)")
        plt.tight_layout()
        outp = OUT_DIR/"plot_full_length_by_ions.png"
        plt.savefig(outp, dpi=180); plt.close()
        print(f"[PLOT] {outp}")

# Per-superfamily plots split by Reaction (Pi and PPi)
def plot_superfamilies_one_kind(df_in, kind="Pi",
                                title_prefix="Protein Length by Superfamily",
                                figsize=(28, 14)):
    from matplotlib.lines import Line2D
    sub = df_in[df_in["Reaction"] == kind].copy()
    fig, ax = plt.subplots(figsize=figsize, constrained_layout=True)
    if sub.empty or "Superfamily" not in sub.columns:
        ax.axis("off"); ax.set_title(f"No data for {kind}")
        return fig
    med = sub.groupby("Superfamily")["UniProt_length"].median().sort_values(ascending=False)
    order_sf = med.index.tolist()
    pos  = np.arange(len(order_sf))
    data = [sub.loc[sub["Superfamily"]==sf, "UniProt_length"].dropna().values for sf in order_sf]

    ax.boxplot(
        data, positions=pos, widths=0.7, vert=True, patch_artist=True,
        boxprops=dict(facecolor="#F2F2F2", edgecolor="#444", linewidth=1.8),
        medianprops=dict(color="black", linewidth=2.2),
        whiskerprops=dict(color="#444", linewidth=1.6),
        capprops=dict(color="#444", linewidth=1.6),
        flierprops=dict(marker="o", markersize=5, markerfacecolor="black", alpha=0.5)
    )

    # colour SF labels by avg ions (if present)
    if "Extra_Ions" in sub.columns:
        avg_ions = sub.groupby("Superfamily")["Extra_Ions"].mean().reindex(order_sf).fillna(0)
    else:
        avg_ions = pd.Series(0, index=order_sf)

    ax.set_xticks(pos)
    ax.set_xticklabels(order_sf, rotation=60, ha="right", fontsize=12)
    for tick, sf in zip(ax.get_xticklabels(), order_sf):
        tick.set_color(_ion_color(avg_ions.loc[sf]))

    ax.set_ylabel("Protein Length (aa)", fontsize=14)
    ax.set_title(f"{title_prefix} — {kind}", pad=6, fontsize=16)
    ax.tick_params(axis="y", labelsize=12)
    ax.set_ylim(bottom=0)

    legend_elems = [
        Line2D([0],[0], color=_ion_color(v), lw=0, marker='s', markersize=10, label=lab)
        for v, lab in [(1,"1"),(2,"2"),(3,"3")]
    ]
    ax.legend(handles=legend_elems, loc="upper left",
              bbox_to_anchor=(1.01, 1), frameon=False, title="Avg metal ions")
    return fig

if {"Reaction","Superfamily"} <= set(df.columns):
    with plt.rc_context({"figure.constrained_layout.use": True}):
        fig = plot_superfamilies_one_kind(df, kind="Pi",  figsize=(28,14))
        outp = OUT_DIR/"plot_full_length_by_sf_Pi.png"; fig.savefig(outp, dpi=160); plt.close(fig); print(f"[PLOT] {outp}")
        fig = plot_superfamilies_one_kind(df, kind="PPi", figsize=(28,14))
        outp = OUT_DIR/"plot_full_length_by_sf_PPi.png"; fig.savefig(outp, dpi=160); plt.close(fig); print(f"[PLOT] {outp}")

print("\n[DONE] Tables + plots saved in:", OUT_DIR.resolve())
