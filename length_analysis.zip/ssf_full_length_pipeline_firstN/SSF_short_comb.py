# -*- coding: utf-8 -*-
"""
Two-stage pipeline for SSF → UniProt → lengths (first-N only)
  MODE="fetch"   : fetch & cache first-N UniProt accessions per SSF (parallel across SSFs)
  MODE="lengths" : read cached accessions (or fetch first-N if missing), fetch lengths, write summaries

Resumable:
- Accessions cached per SSF in FETCH_DIR/{SSF}.tsv
- Lengths appended to LEN_FILE (skips already-seen accessions)
"""

import os, re, csv, time, json, gzip, hashlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

import pandas as pd
import numpy as np

# ===================== USER CONFIG =====================
MODE              = "lengths"      # "fetch" or "lengths"
PARALLEL_JOBS     = 8              # threads across SSFs (fetch mode only)

# Limit how many UniProt IDs we handle per SSF in this run
LIMIT_PER_SSF     = 1000            # set None to disable; used in both modes

# UniProt querying
UNIPROT_BATCH_START   = 150        # starting batch; auto-scales down if server rejects
UNIPROT_PARALLEL_GET  = 12         # threads for per-accession fallback
UNIPROT_BASE          = "https://rest.uniprot.org/uniprotkb"
UNIPROT_SEARCH        = f"{UNIPROT_BASE}/search"

# InterPro API
IP_BASE            = "https://www.ebi.ac.uk/interpro/api"
IP_PAGE_SIZE       = 200
IP_PAGE_DELAY      = 0.2           # polite delay between pages
TIMEOUT_CONN_READ  = (6.0, 60.0)   # (connect, read) seconds

# Paths
BASE      = r"C:\Users\edina\Dropbox\bdudas\metalcoord\manuscript\revision\check_length"
MAP_CSV   = os.path.join(BASE, "reps_rxn_metalNO.csv")        # curated file with SSF column
SIFTS_TSV_GZ = os.path.join(BASE, "pdb_chain_uniprot.tsv.gz") # optional; set to None to disable

OUT_DIR   = Path(BASE) / "ssf_full_length_pipeline_firstN"
FETCH_DIR = OUT_DIR / "cache_ssf_uniprot_lists"   # per-SSF accession lists
LEN_FILE  = OUT_DIR / "ssf_uniprot_lengths_firstN.csv"   # final appended lengths

USE_SIFTS_FILTER = None   # True to restrict to UniProts with PDB structures (via SIFTS)
# =======================================================

OUT_DIR.mkdir(parents=True, exist_ok=True)
FETCH_DIR.mkdir(parents=True, exist_ok=True)

# ---------------- HTTP session with retries -------------
def make_session(total_retries=5, backoff_factor=0.8,
                 status_forcelist=(429, 500, 502, 503, 504)):
    s = requests.Session()
    retry = Retry(
        total=total_retries, read=total_retries, connect=total_retries,
        status_forcelist=status_forcelist,
        allowed_methods=frozenset(["GET", "HEAD", "OPTIONS", "POST"]),
        backoff_factor=backoff_factor,
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=32, pool_maxsize=64)
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    return s

SESSION = make_session()

# --------------- utility helpers -----------------------
def norm_cols(cols):
    return (cols.astype(str)
                .str.replace("\ufeff", "", regex=False)
                .str.strip().str.lower().str.replace(r"\s+"," ", regex=True))

def normalise_rxn(s):
    s2 = (s.astype(str).str.upper().str.replace(r"\s+","",regex=True))
    return np.where(s2.str.contains("PP"), "PP", "P")

def safe_to_csv(df, path: Path, mode="w"):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = (mode == "w") or (not path.exists())
    df.to_csv(path, index=False, mode=mode, header=write_header)

def read_mapping_with_ssf(map_csv):
    m = pd.read_csv(map_csv, sep=None, engine="python", encoding="utf-8-sig")
    m.columns = norm_cols(m.columns)
    # aliases
    def pick(df, opts, required=True):
        for o in opts:
            if o in df.columns: return o
        if required: raise SystemExit(f"Missing col; need one of {opts}\nHave: {list(df.columns)}")
        return None

    c_rxn  = pick(m, ["reaction","pi_pp","phosphate_type"])
    c_sf   = pick(m, ["sf","superfamily","sf name","superfamily name"])
    c_ion  = pick(m, ["extraions","extra_ions","metals","n_metals"])
    c_ssf  = pick(m, ["ssf","ssf_id","ssf id","scop_superfamily","superfamily (ssf)"])

    m = m.rename(columns={c_rxn:"Reaction", c_sf:"SF", c_ion:"Extra_Ions", c_ssf:"SSF_ID"})
    m["ReactionPP"] = normalise_rxn(m["Reaction"])
    m["Extra_Ions"] = pd.to_numeric(m["Extra_Ions"], errors="coerce")
    m["SF"] = m["SF"].astype(str).str.strip()
    m["SSF_ID"] = m["SSF_ID"].astype(str).str.strip()
    # keep valid SSF IDs only (like SSF55083)
    m = m[m["SSF_ID"].str.match(r"^SSF\d+$", na=False)].copy()
    return m

# --------------- SIFTS filter ---------------------------
def read_sifts_uniprot_set(path_gz):
    if (not USE_SIFTS_FILTER) or (path_gz is None) or (not os.path.exists(path_gz)):
        return None
    u_set = set()
    with gzip.open(path_gz, "rt", encoding="utf-8") as fh:
        header = fh.readline().strip().split("\t")
        if "SP_PRIMARY" in header:
            uidx = header.index("SP_PRIMARY")
        elif "UNIPROT" in header:
            uidx = header.index("UNIPROT")
        else:
            uidx = -1
        for ln in fh:
            toks = ln.rstrip("\n").split("\t")
            if toks:
                u_set.add(toks[uidx])
    return u_set

# --------------- InterPro: per-SSF fetch ----------------
def cache_path_for_ssf(ssf_id: str) -> Path:
    return FETCH_DIR / f"{ssf_id}.tsv"

def save_accessions(ssf_id: str, accs):
    df = pd.DataFrame({"UniProt": accs})
    safe_to_csv(df, cache_path_for_ssf(ssf_id), mode="w")

def load_accessions_if_cached(ssf_id: str):
    fp = cache_path_for_ssf(ssf_id)
    if fp.exists():
        try:
            df = pd.read_csv(fp, sep=",")
            return df["UniProt"].dropna().astype(str).tolist()
        except Exception:
            # try TSV
            df = pd.read_csv(fp, sep="\t", header=0)
            return df.iloc[:,0].dropna().astype(str).tolist()
    return None

def fetch_interpro_first_n_uniprot_for_ssf(ssf_id: str, n: int, page_size=IP_PAGE_SIZE):
    """
    Fetch ONLY the first n UniProt accessions for an SSF (sequential pages; stops early).
    """
    assert re.fullmatch(r"SSF\d+", ssf_id), f"Bad SSF id: {ssf_id}"
    if n is None or n <= 0:
        return []

    url = f"{IP_BASE}/protein/UniProt/entry/ssf/{ssf_id}/"
    params = {"page_size": page_size}
    seen = []
    page = 0
    t0 = time.time()
    while url and len(seen) < n:
        page += 1
        try:
            r = SESSION.get(url, params=params, headers={"Accept":"application/json"},
                            timeout=TIMEOUT_CONN_READ)
            if r.status_code == 408:
                print(f"   [IP] {ssf_id} page {page}: 408 timeout → sleep 61s")
                time.sleep(61); continue
            if r.status_code == 204:
                break
            r.raise_for_status()
            payload = r.json()
        except requests.exceptions.RequestException as e:
            print(f"   [IP] {ssf_id} page {page}: error {e} → retrying in 3s…")
            time.sleep(3)
            try:
                r = SESSION.get(url, params=params, headers={"Accept":"application/json"},
                                timeout=TIMEOUT_CONN_READ)
                r.raise_for_status()
                payload = r.json()
            except Exception as e2:
                print(f"   [IP] {ssf_id} page {page}: failed again ({e2}) → stop.")
                break

        results = payload.get("results", [])
        added = 0
        for item in results:
            acc = ((item or {}).get("metadata") or {}).get("accession")
            if acc:
                seen.append(acc); added += 1
                if len(seen) >= n:
                    break

        if page == 1 or (page % 5) == 0:
            print(f"   [IP] {ssf_id} page {page:>4} | +{added} | total={len(seen)} | {time.time()-t0:0.1f}s")

        if len(seen) >= n:
            break

        url = payload.get("next")
        params = None
        if url: time.sleep(IP_PAGE_DELAY)

    print(f"   [IP] {ssf_id} first-{n} done: {len(seen)} accessions.")
    return seen

def fetch_one_ssf_worker_firstN(ssf_id: str, label: str, n: int):
    # resume if cached
    cached = load_accessions_if_cached(ssf_id)
    if cached is not None and len(cached) > 0:
        # If cache has more than n, trim (don’t rewrite file, just report)
        use = cached[:n] if n is not None else cached
        print(f"[CACHE] {ssf_id} ({label}): using {len(use)} of {len(cached)} cached accessions")
        return ssf_id, len(use), True
    print(f"[FETCH] {ssf_id} ({label}): fetching first {n}…")
    accs = fetch_interpro_first_n_uniprot_for_ssf(ssf_id, n=n)
    save_accessions(ssf_id, accs)
    return ssf_id, len(accs), False

# --------------- UniProt lengths -----------------------
def _get_length_one(acc: str):
    """Per-accession fallback: GET TSV fields=accession,length"""
    url = f"{UNIPROT_BASE}/{acc}.tsv"
    params = {"fields": "accession,length"}
    try:
        r = SESSION.get(url, params=params, timeout=TIMEOUT_CONN_READ)
        if r.status_code in (408, 429, 503):
            time.sleep(3)
            r = SESSION.get(url, params=params, timeout=TIMEOUT_CONN_READ)
        r.raise_for_status()
        lines = r.text.splitlines()
        if len(lines) >= 2 and "\t" in lines[1]:
            a, L = lines[1].split("\t")
            return a, int(L)
    except Exception:
        return None
    return None

def uniprot_lengths_bulk(accessions, batch_start=UNIPROT_BATCH_START):
    """
    Robustly fetch UniProt lengths.
    Strategy:
      1) POST batch query to /uniprotkb/search with fields=accession,length
      2) On 400/413/414/500: auto-shrink batch size (down to 25)
      3) If still failing, fallback to per-accession GET in parallel
    Returns DataFrame [UniProt, UniProt_length]
    """
    if not accessions:
        return pd.DataFrame(columns=["UniProt", "UniProt_length"])

    out = []
    total = len(accessions)
    i = 0
    t0 = time.time()
    cur_batch = max(25, int(batch_start))

    # ---- Phase 1: POST batch loop ----
    while i < total and cur_batch >= 25:
        chunk = accessions[i:i+cur_batch]
        data = {
            "query": "accession:(" + " OR ".join(chunk) + ")",
            "fields": "accession,length",
            "format": "tsv",
            "size": cur_batch
        }
        try:
            r = SESSION.post(UNIPROT_SEARCH, data=data, timeout=TIMEOUT_CONN_READ)
            if r.status_code in (408, 429, 503):
                print(f"   [UP] server busy (HTTP {r.status_code}); sleep 10s & retry same chunk…")
                time.sleep(10)
                continue
            if r.status_code in (400, 413, 414, 500):
                newb = cur_batch // 2
                if newb >= 25:
                    print(f"   [UP] HTTP {r.status_code} on batch={cur_batch} → shrinking to {newb} and retrying…")
                    cur_batch = newb
                    continue
                else:
                    print("   [UP] Batch too big even at 25 → switch to per-accession fallback for remaining.")
                    break
            r.raise_for_status()

            lines = r.text.splitlines()
            got = 0
            for ln in lines[1:]:
                if not ln.strip(): continue
                acc, length = ln.split("\t")
                out.append((acc, int(length))); got += 1

            i += cur_batch
            done = min(i, total)
            print(f"   [UP] {done}/{total} | chunk={cur_batch} | +{got} rows | {time.time()-t0:0.1f}s")
            time.sleep(0.12)
        except requests.exceptions.RequestException as e:
            print(f"   [UP] network/server error on batch={cur_batch}: {e} → retry in 6s…")
            time.sleep(6)

    remaining = accessions[i:]
    # ---- Phase 2: per-accession fallback if needed ----
    if remaining:
        print(f"   [UP] Fallback per-accession GET for {len(remaining)} IDs (parallel={UNIPROT_PARALLEL_GET})…")
        t1 = time.time()
        with ThreadPoolExecutor(max_workers=UNIPROT_PARALLEL_GET) as ex:
            futures = {ex.submit(_get_length_one, acc): acc for acc in remaining}
            done = 0; got = 0
            for fut in as_completed(futures):
                res = fut.result()
                done += 1
                if res is not None:
                    out.append(res); got += 1
                if (done % 200) == 0 or done == len(remaining):
                    print(f"     [UP] fallback progress {done}/{len(remaining)} | +{got} ok | {time.time()-t1:0.1f}s")

    if not out:
        return pd.DataFrame(columns=["UniProt","UniProt_length"])
    df = pd.DataFrame(out, columns=["UniProt","UniProt_length"]).drop_duplicates("UniProt")
    return df

def append_lengths_csv(path: Path, df: pd.DataFrame):
    write_header = not path.exists()
    df.to_csv(path, mode="a", header=write_header, index=False)

# ====================== MAIN ===========================
def main():
    m = read_mapping_with_ssf(MAP_CSV)

    # group to unique SSF IDs (keep SF/Reaction/Extra_Ions meta from first row)
    groups = []
    for ssf_id, sub in m.groupby("SSF_ID", dropna=False):
        meta = sub.iloc[0]
        groups.append({
            "SSF_ID": ssf_id,
            "SF": meta.get("SF", ssf_id),
            "ReactionPP": meta.get("ReactionPP", "P"),
            "Extra_Ions": meta.get("Extra_Ions", np.nan),
        })
    ssf_tbl = pd.DataFrame(groups)
    print(f"[INFO] Unique SSFs to process: {len(ssf_tbl)}")

    # Optional SIFTS filter
    sifts_set = read_sifts_uniprot_set(SIFTS_TSV_GZ)
    if USE_SIFTS_FILTER:
        if sifts_set is None:
            print("[INFO] SIFTS filter requested but file missing/disabled → proceeding WITHOUT SIFTS filter.")
        else:
            print(f"[INFO] SIFTS filter active: {len(sifts_set):,} UniProt accessions with PDB coverage.")

    if MODE.lower() == "fetch":
        print(f"[MODE] FETCH — parallel={PARALLEL_JOBS} — first {LIMIT_PER_SSF} IDs only")
        futures = []
        with ThreadPoolExecutor(max_workers=PARALLEL_JOBS) as ex:
            for _, row in ssf_tbl.iterrows():
                futures.append(ex.submit(fetch_one_ssf_worker_firstN, row["SSF_ID"], row["SF"], LIMIT_PER_SSF))
            done = 0
            for fut in as_completed(futures):
                ssf_id, n, from_cache = fut.result()
                done += 1
                src = "cache" if from_cache else "fetch"
                print(f"[{done}/{len(futures)}] {ssf_id}: {n} accessions ({src})")
        print(f"[DONE] Fetch mode complete. Cached lists in {FETCH_DIR}")

    elif MODE.lower() == "lengths":
        print(f"[MODE] LENGTHS — first {LIMIT_PER_SSF} IDs per SSF (fetch on-demand if missing)")

        # Build a quick index of what we already wrote (to allow resume)
        already = set()
        if LEN_FILE.exists():
            try:
                tmp = pd.read_csv(LEN_FILE, usecols=["UniProt"])
                already = set(tmp["UniProt"].astype(str))
                print(f"[RESUME] Found {len(already):,} UniProt already in {LEN_FILE.name} — will skip.")
            except Exception:
                pass

        all_written = 0
        for _, row in ssf_tbl.iterrows():
            ssf_id = row["SSF_ID"]
            label  = row["SF"]
            rxn    = row["ReactionPP"]
            ions   = row["Extra_Ions"]

            accs = load_accessions_if_cached(ssf_id)
            if not accs or len(accs) == 0:
                n = LIMIT_PER_SSF if LIMIT_PER_SSF is not None else 100
                print(f"\n[LEN] {ssf_id} ({label}): no cache → fetching first {n} accessions…")
                accs = fetch_interpro_first_n_uniprot_for_ssf(ssf_id, n=n)
                save_accessions(ssf_id, accs)
            elif LIMIT_PER_SSF is not None and len(accs) < LIMIT_PER_SSF:
                # Top-up/refresh cache to first-LIMIT_PER_SSF
                print(
                    f"\n[LEN] {ssf_id} ({label}): cache has {len(accs)} < {LIMIT_PER_SSF} → fetching first {LIMIT_PER_SSF}…")
                accs = fetch_interpro_first_n_uniprot_for_ssf(ssf_id, n=LIMIT_PER_SSF)
                save_accessions(ssf_id, accs)

            # Trim if cache has more than LIMIT for this run
            if LIMIT_PER_SSF is not None and len(accs) > LIMIT_PER_SSF:
                accs = accs[:LIMIT_PER_SSF]
                print(f"\n[LEN] {ssf_id} ({label}): using first {LIMIT_PER_SSF} cached accessions.")

            print(f"[LEN] {ssf_id} ({label}): working set size = {len(accs)}")

            if USE_SIFTS_FILTER and sifts_set is not None:
                before = len(accs)
                accs = [a for a in accs if a in sifts_set]
                print(f"   [SIFTS] {before} → {len(accs)}")
                if not accs:
                    print("   [SKIP] empty after SIFTS filter.")
                    continue

            # Skip those already written
            if already:
                before = len(accs)
                accs = [a for a in accs if a not in already]
                if before != len(accs):
                    print(f"   [RESUME] skipping {before-len(accs)} already done; remaining {len(accs)}")

            if not accs:
                print("   [SKIP] nothing to do for this SSF.")
                continue

            lens = uniprot_lengths_bulk(accs, batch_start=UNIPROT_BATCH_START)
            if lens.empty:
                print("   [SKIP] no lengths returned.")
                continue

            lens = lens.assign(SSF_ID=ssf_id, SF=label, Reaction=rxn, Extra_Ions=ions)
            append_lengths_csv(LEN_FILE, lens)
            all_written += len(lens)
            already.update(lens["UniProt"].astype(str))
            print(f"   [APPEND] wrote {len(lens)} rows → {LEN_FILE.name}")

        if all_written == 0:
            print("\n[WARN] No rows written. Check caches & filters.")
            return

        # Summaries
        df = pd.read_csv(LEN_FILE)
        summary_by_ssf = (df.groupby(["SSF_ID","SF"])["UniProt_length"]
                            .agg(["count","min","max","median","mean","std"])
                            .reset_index())
        safe_to_csv(summary_by_ssf, OUT_DIR/"ssf_uniprot_length_summary_by_ssf.csv")

        summary_by_rxn_ion = (df.groupby(["Reaction","Extra_Ions"])["UniProt_length"]
                                .agg(["count","min","max","median","mean","std"])
                                .reset_index())
        safe_to_csv(summary_by_rxn_ion, OUT_DIR/"ssf_uniprot_length_summary_by_rxn_ion.csv")

        print("\n[DONE] Lengths mode complete.")
        print(f" - Appended lengths: {LEN_FILE}")
        print(f" - Summary by SSF  : {OUT_DIR/'ssf_uniprot_length_summary_by_ssf.csv'}")
        print(f" - Summary by Rxn/Ions: {OUT_DIR/'ssf_uniprot_length_summary_by_rxn_ion.csv'}")

    else:
        raise SystemExit("MODE must be 'fetch' or 'lengths'")

if __name__ == "__main__":
    main()
